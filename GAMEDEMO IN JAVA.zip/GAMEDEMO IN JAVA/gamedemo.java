/*import packages requried in our project*/
import java.io.*;//it is required to use file handling 
import java.util.*;//it is required as we used stringbuffer class and stream tokenizer
import java.awt.*;//we used it to create frame for graphic interface
import java.awt.event.*;//used to handle action event on buttons

/* class gamedemo is a Frame and also using ActionListener*/

class gamedemo extends Frame implements ActionListener 
{
/*declaring certain variables for use */
public static int words=0;//used to count no of words in file
	public static int lines=0;
	public static int chars=0,counter=0;
//declared static so it can be directly used without creating class object

	static String sc,snd,sd,stg;
static int chance;//represents no of chances a user has got
static StringBuffer sb;//it is stringbuffer to manipulate string
/*
panel p1 is used for displaying the characters entered by user
panel p2 is used for displaying the interface to enter the 
character from user
panel p3 is used to display success or failure message */

Panel p1,p2,p3;
/* labels are used to display different messages*/
 static Label la,lb,lc;
/*button are used to handle event such as startgame or put the user
choice in textfield at desired location*/
Button ba,bb;
/*tb is textfield to take one character as input from user at one time*/

static TextField tb;

/*TextArea is what we used to display no of - as are in
randomly selected word from file*/

static TextArea ta;
/*public default constructor of gamedemo class makes certain
initialization and creating the components objects */

public gamedemo()
{
setLayout(new GridLayout(3,1));//setting the layout of frame gridlayout
p1=new Panel();//creating panel object
/*creating textarea object with 1 row and 100 columns with no scrollbars
*/
ta=new TextArea(" ",1,100,TextArea.SCROLLBARS_NONE);
//creating the font class object to set the font of message on lable 
Font fs=new Font("TimesNewRoman",Font.BOLD|Font.ITALIC,20);
la=new Label("your word is displayed in this text box");
//creating label object with desired message
la.setFont(fs);//setting the font for label
p1.add(la);//adding the label to panel
p1.add(ta);//adding the textfield to panel
p2=new Panel();//creating second panel 
tb=new TextField();//creating textfield object to take character input
//from user
lb=new Label("enter one character and press button go");//create label
lb.setFont(fs);//setFont is method of component class 
//is used to set Font for any component
p2.add(lb);//adding label to panel p2
p2.add(tb);//adding textfield to panel p2
ba=new Button("start the game");//creating button for starting game
//to handle actionevent on button source you should addlistener with 
//its object as argument,listener is object of class which 
//implements corrosponding interface here our gamedemo class does
//so we can pass this in constructor of this class
ba.addActionListener(this);

bb=new Button("go");//creating button to accept a char from user
bb.addActionListener(this);//handling action event on button bb
//this performs the operation of checking whether user entered 
//correct letter or not and doing desired operation
p2.add(ba);//adding button to panel p2
p2.add(bb);//adding button to panel p2
p3=new Panel();//creating third panel p3
p3.setLayout(new BorderLayout());//setting layout as border layout for
//panel p3 as we want the message to be displayed in center and full
lc=new Label("                              ");//create a blank label
p3.add(lc);//adding lable to panel p3
/*setting the background color of different
panels using setBackground method of component class */
p1.setBackground(Color.orange);
p2.setBackground(Color.cyan);
p3.setBackground(Color.yellow);
add(p1);//adding panel p1 to frame
add(p2);//adding panel p2 to frame
add(p3);//adding panel p3 to frame
/* using anonymous inner class for handling window event to close
the frame on clicking close option displayed on top left of frame
we handled windowClosing method of windowAdapter class
to override it with System.exit(0) to exit from your program*/

addWindowListener(new WindowAdapter()
         {  public void windowClosing(WindowEvent e)
            {  System.exit(0);
            }
         } );
setSize(500,500);//setting the size of frame
setVisible(true);//frames are not visible by default setVisible method
//makes it visible
}//closing constructor

/* implementing actionlistener interface method
by defining actionPerformed method*/
public void actionPerformed(ActionEvent ae){
//to check whether which button was clicked you can use getSource method
//and compare it with button object
if(ae.getSource()==ba){
startgame();//it is used to start the game and display desired no
//of - marks in text area for user to enter 
}
else if(ae.getSource()==bb)
{
putchar();//it is used to get character from user and setting it on
//textarea made earlier
}
}//closing actionPerformed method

/*putchar method when invoked takes character out of the textfield
and compares with the chararcer in word randomly selected
if it matches then it displayes it at its correct position
else it displayes a message regarding one step closer to hang*/

public static void putchar()
{
if(chance !=0){//checking whether user has more chances left
snd=ta.getText();//getting the text from textfield
char ct[]=new char[10];//a character array
int m=sc.length();//find the length of word randomly selected
int i=0;
/* getting the character from randomly selected form file and storing 
it in a char array for comparision with char entered by user*/
for(int d=0;d<m;d++)
{
char c1=sc.charAt(d);
ct[i]=c1;
if(i>=m)//break out of loop if the no of character to be stored in
//array is more then no of chars in word selected
{break;
}
i++;
}
String sa="";//creating a blank string
String sm=tb.getText();//getting the text from user and storing in 
//a string sm

char fg[]=sm.toCharArray();//converting the string to a character array
/*comparing whether the character is in word selected by user
if it is then no of positions at which it occours are appended
to a string sa*/
for(int p=0;p<m;p++)
{if(ct[p]==fg[0])//checking if it is in selected word or not
{ sa +=String.valueOf(p);//method gets string value of an integer
}
}
//indexof method is used to find the starting index of 
//a string sm into sc if it does not exist
//in that string then -1 is returned
if(sc.indexOf(sm) == -1)
{
Font ft=new Font("TimesNewRoman",Font.BOLD,40);
lc.setFont(ft);
lc.setBackground(Color.green);
lc.setForeground(Color.red);
lc.setText("you are one step closer to being hanged");
}
else{
lc.setText("                             ");//will set the message
//to blank as a user enter the correct character
int set[]=new int[10];//is used to find location to place character
//in textarea
//check whether how many times you have to place the
//character and at what locations
for(int k=0;k<sa.length();k++)
{
char ca=sa.charAt(k);//taking the location out of string
char data[]={ca};//getting a char array requierd as you need to
//convert it to string the to integer

int md=Integer.parseInt(new String(data));//get int out of string
//storing the integer to a integer array
set[k]=md;
}
int nd=0;
/*using string buffer as mutable string  from the string displayed
as - marks in text area*/
sb=new StringBuffer(snd);//snd retrieved from textarea
/* loop is used to place the character at disered location
considering the spaces used for better visibility*/
for(int j=0;j<set.length;j++)
{
if(j>=sa.length())//break out if the no of character repeated 
//exceeds the length of arry
{
break;
}
 nd=set[j]*4;//generating 4 additional spaces requied
 //setting char at nd index with fg[0] character entered by user
sb.setCharAt(nd,fg[0]);
//increasing the counter as number of the locations blank a
//user has to enter the character
counter++;
}

Font fd=new Font("TimesNewRoman",Font.BOLD,40);
ta.setText(sb.toString());
//if counter is equal to number of characters in word user has won
if(counter == sc.length()){
lc.setFont(fd);
lc.setText("YOU HAVE WON THE GAME");
}

}
//reducing the number of chances with each attempt
chance--;

}
//a losing message is displayed if counter chances are zero remaining
else{
Font fd=new Font("TimesNewRoman",Font.BOLD,40);
lc.setFont(fd);
lc.setText("SORRY SIR TRY AGAIN YOU LOST THIS TIME");
}
}
/* method for starting of game*/
public static void startgame()
{
/* reading the string from file and then by using sting tokenizer
class we separeted indivisual words from string read from file
and stored in array*/
String sar[]=new String[10];
		int i=0;
		try{
		FileInputStream fis=new FileInputStream("demo.txt");
		DataInputStream dis=new DataInputStream(fis);
		String st=dis.readLine();
		System.out.println(st);
FileInputStream fis1=new FileInputStream("demo.txt");
			
		StringTokenizer stg=new StringTokenizer(st);
while(stg.hasMoreTokens())//checks whether there are more words 
//separated by whitespace
{
System.out.println(st);
String s1=stg.nextToken();//getting next word from string
System.out.println(s1);
sar[i]=s1;
System.out.println(st);
//storing in it an array of words
if (i>=10)//if array index is more then 10 break out of loop
{break;
}
i++;
}

	//generate a random number to select a random word from file
	double rno=Math.random();
	int x=(int)(rno*10);//multiply it with 10 and typecasting to int
	//gets an integer between 0 -9
	 sc=sar[x];//getting the word from word array and storing to a string

	int len=sc.length();//getting the length of word randomly selected
	chance=len*2;//solution of problem no 1 ie
	//no of chances are double to no of charcters in word
	//make it chance=len if you want to solve problem2
	//ie no of chances are equal to no of characters
	
	/* display the no of _ in text area as many no of characters in word*/

	for(int m=0;m<len;m++){
	ta.append("_   ");//append method is useful to append already
	//existing charcter in textarea but setText method does not
	//provide this advantage
	}//for closed
	
		}catch(IOException e){};//catch io exception
		
		}//close method
	

	public static void main(String[] args) 
	{gamedemo gd=new gamedemo();//creating object of gamedemo class
	}
}//close class
