/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oosd.university;

//Imports are listed in full to show what's being used
//could just import javax.swing.* and java.awt.* etc..
import java.awt.EventQueue;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import javax.swing.BorderFactory;
import javax.swing.border.Border;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Container;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
//import java.awt.Color;
import java.awt.Font;
//import java.awt.event.ActionEvent;
//import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
//import javax.swing.JButton;
//import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.*;
import java.io.*;
import java.util.*;

public class StudenntInformationSystem {

    /**
     * @param args the command line arguments
     */
    JFrame guiFrame;
JTable table;
CardLayout cards;
BorderLayout boards;
JPanel cardPanel,firstCard,secondCard,thirdCard,fourthCard,fifthCard;
JButton jbtSave,jbtLoad;
JFileChooser myJFileChooser;
DefaultTableModel model;
 
public static void main(String[] args) {
//Use the event dispatch thread for Swing components
EventQueue.invokeLater(new Runnable()
{
//@Override
public void run()
{
new StudenntInformationSystem();
}
});
}
public StudenntInformationSystem()
{
guiFrame = new JFrame();
//make sure the program exits when the frame closes
guiFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
guiFrame.setTitle("STUDENT MANAGEMENT SYSTEM");
guiFrame.setSize(400,300);
//This will center the JFrame in the middle of the screen
guiFrame.setLocationRelativeTo(null);
guiFrame.setLayout(new BorderLayout());
//creating a border to highlight the JPanel areas
Border outline = BorderFactory.createLineBorder(Color.black);
JPanel tabsPanel = new JPanel();
tabsPanel.setBorder(outline);
JButton switchCards = new JButton("STUDENT           ||TEACHER        ||MODULE       ||COURSE             ||UNIVERSITY");
switchCards.setActionCommand("Switch Card");
switchCards.addActionListener(new ActionListener()
{ 
//@Override
public void actionPerformed(ActionEvent event)
{
cards.next(cardPanel);
}
});
tabsPanel.add(switchCards);
guiFrame.add(tabsPanel,BorderLayout.NORTH);
cards = new CardLayout();
cardPanel = new JPanel();
cardPanel.setLayout(cards);
boards =new BorderLayout();
cards.show(cardPanel, "UNIVERSITY");
 firstCard = new JPanel();
 
  firstCard.setBackground(Color.GREEN);
//addButton(firstCard, "STUDENT INFORMATON");

firstCard.setLayout(boards);
Student t = new Student();
t.common(firstCard);



 secondCard = new JPanel();
 secondCard.setLayout(boards);
 Teacher tg= new Teacher();
 tg.common(secondCard);
//functionality2(secondCard);

secondCard.setBackground(Color.BLUE);



 thirdCard = new JPanel();
 thirdCard.setLayout(boards);
 Module m= new Module();
m.common(thirdCard);

thirdCard.setBackground(Color.YELLOW);

 fourthCard = new JPanel();
fourthCard.setLayout(boards);
Course cs= new Course();
cs.common(fourthCard);
//functionality4(fourthCard);

fourthCard.setBackground(Color.ORANGE);

 fifthCard = new JPanel();
 fifthCard.setLayout(boards);
 University us= new University();
 us.common(fifthCard);
//functionality5(fifthCard);



fifthCard.setBackground(Color.RED);


cardPanel.add(firstCard, "STUDENT");
cardPanel.add(secondCard, "LECTURE");
cardPanel.add(thirdCard, "MODULE");
cardPanel.add(fourthCard, "COURSE");
cardPanel.add(fifthCard, "UNIVERSITY");


guiFrame.add(tabsPanel,BorderLayout.NORTH);
guiFrame.add(cardPanel,BorderLayout.CENTER);
guiFrame.setVisible(true);
}
//All the buttons are following the same pattern
//so create them all in one place.
private void addButton(Container parent, String name)
{
JButton but = new JButton(name);
but.setActionCommand(name);
parent.add(but);
}
    
}
