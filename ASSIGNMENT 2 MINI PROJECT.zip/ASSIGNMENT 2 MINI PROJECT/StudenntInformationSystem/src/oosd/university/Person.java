/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oosd.university;

import java.awt.EventQueue;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import javax.swing.BorderFactory;
import javax.swing.border.Border;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Container;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
//import java.awt.Color;
import java.awt.Font;
//import java.awt.event.ActionEvent;
//import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
//import javax.swing.JButton;
//import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.*;
import java.io.*;
import java.util.*;

public class Person {
    
    JFrame guiFrame;
JTable table;
CardLayout cards;
BorderLayout boards;
JPanel cardPanel,firstCard,secondCard,thirdCard,fourthCard,fifthCard;
JButton jbtSave,jbtLoad,btnAdd,btnDelete,btnUpdate;
JFileChooser myJFileChooser;
DefaultTableModel model;
 JTextField textId,textFname,textLname,textAge;

public void common( Object[] st){
	 table = new JTable(); 
	  myJFileChooser = new JFileChooser(new File("."));

	   jbtSave = new JButton("Save Table");
     jbtLoad = new JButton("Load Table");
 model = new DefaultTableModel();
        model.setColumnIdentifiers(st);
        
        // set the model to the table
        table.setModel(model);
        
        // Change A JTable Background Color, Font Size, Font Color, Row Height
        table.setBackground(Color.LIGHT_GRAY);
        table.setForeground(Color.black);
        Font font = new Font("",1,22);
        table.setFont(font);
        table.setRowHeight(30);
        
        // create JTextFields
    
}
    
}
