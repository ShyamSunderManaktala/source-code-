/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oosd.university;


import java.awt.EventQueue;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import javax.swing.BorderFactory;
import javax.swing.border.Border;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Container;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
//import java.awt.Color;
import java.awt.Font;
//import java.awt.event.ActionEvent;
//import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
//import javax.swing.JButton;
//import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.*;
import java.io.*;
import java.util.*;
public class Module extends Person {
    
    
    public void common(JPanel p)
	{
	 
       

        // create a table model and set a Column Identifiers to this model 
      Object[] columns = {"MODULE ID","YEAR","BRANCH","SEMESTER"};
         common(columns);

		 //System.out.println("hhhhhhhhhh");
		
        JLabel js= new JLabel(" MODULE INFORMATION");
		js.setBounds(800,0,1360,10);
        // create JScrollPane
        JScrollPane pane = new JScrollPane(table);
        pane.setBounds(0, 20, 1360, 200);
        
        p.setLayout(null);
        p.add(js);
       p.add(pane);

	       JTextField textId = new JTextField();
        JTextField textFname = new JTextField();
        JTextField textLname = new JTextField();
        JTextField textAge = new JTextField();
        
        // create JButtons
        JButton btnAdd = new JButton("Add");
        JButton btnDelete = new JButton("Delete");
        JButton btnUpdate = new JButton("Update");     
        
        textId.setBounds(40, 220, 100, 25);
        textFname.setBounds(40, 250, 100, 25);
        textLname.setBounds(40, 280, 100, 25);
        textAge.setBounds(40, 310, 100, 25);
        
        btnAdd.setBounds(150, 220, 100, 25);
        btnUpdate.setBounds(150, 265, 100, 25);
        btnDelete.setBounds(150, 310, 100, 25);

        
        // add JTextFields to the jframe
       p.add(textId);
        p.add(textFname);
       p.add(textLname);
        p.add(textAge);
    
        // add JButtons to the jframe
        p.add(btnAdd);
        p.add(btnDelete);
         p.add(btnUpdate);
		jbtSave.setBounds(150, 355, 100, 25);
		jbtLoad.setBounds(150, 400, 100, 25);
		 p.add(jbtSave);
		 p.add(jbtLoad);

    
	   
        jbtSave.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                saveTable(p);
            }
        });
 
        jbtLoad.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                loadTable(p);
            }
        });
        
        // create an array of objects to set the row data
        Object[] row = new Object[4];
        
        // button add row
        btnAdd.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent e) {
             
                row[0] = textId.getText();
                row[1] = textFname.getText();
                row[2] = textLname.getText();
                row[3] = textAge.getText();
                
                // add row to the model
                model.addRow(row);
            }
        });
        
        // button remove row
        btnDelete.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent e) {
            
                // i = the index of the selected row
                int i = table.getSelectedRow();
                if(i >= 0){
                    // remove a row from jtable
                    model.removeRow(i);
                }
                else{
                    System.out.println("Delete Error");
                }
            }
        });
        
        // get selected row data From table to textfields 
        table.addMouseListener(new MouseAdapter(){
        
        @Override
        public void mouseClicked(MouseEvent e){
            
            // i = the index of the selected row
            int i = table.getSelectedRow();
            
            textId.setText(model.getValueAt(i, 0).toString());
            textFname.setText(model.getValueAt(i, 1).toString());
            textLname.setText(model.getValueAt(i, 2).toString());
            textAge.setText(model.getValueAt(i, 3).toString());
        }
        });
        
        // button update row
        btnUpdate.addActionListener(new ActionListener(){

            @Override
            public void actionPerformed(ActionEvent e) {
             
                // i = the index of the selected row
                int i = table.getSelectedRow();
                
                if(i >= 0) 
                {
                   model.setValueAt(textId.getText(), i, 0);
                   model.setValueAt(textFname.getText(), i, 1);
                   model.setValueAt(textLname.getText(), i, 2);
                   model.setValueAt(textAge.getText(), i, 3);
                }
                else{
                    System.out.println("Update Error");
                }
            }
        });
}
	
	 
     
    private void saveTable( JPanel ps) {
        if (myJFileChooser.showSaveDialog(ps) ==
                JFileChooser.APPROVE_OPTION ) {
            saveTable(myJFileChooser.getSelectedFile());
        }
    }
     
    private void saveTable(File file) {
        try {
            ObjectOutputStream out = new ObjectOutputStream(
                    new FileOutputStream(file));
                out.writeObject(model.getDataVector());
                out.writeObject(getColumnNames());
                out.close();
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
    }
     
    private Vector<String> getColumnNames() {
        Vector<String> columnNames = new Vector<String>();
        for (int i = 0; i < table.getColumnCount(); i++)
            columnNames.add(table.getColumnName(i) );
            return columnNames;
    }
     
    private void loadTable( JPanel ps) {
        if (myJFileChooser.showOpenDialog(ps) ==
                JFileChooser.APPROVE_OPTION )
            loadTable(myJFileChooser.getSelectedFile());
    }
     
    private void loadTable(File file) {
        try {
            ObjectInputStream in = new ObjectInputStream(
            new FileInputStream(file));
            Vector rowData = (Vector)in.readObject();
            Vector columnNames = (Vector)in.readObject();
            model.setDataVector(rowData, columnNames);
            in.close();
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
	
	
	
	
    
}
