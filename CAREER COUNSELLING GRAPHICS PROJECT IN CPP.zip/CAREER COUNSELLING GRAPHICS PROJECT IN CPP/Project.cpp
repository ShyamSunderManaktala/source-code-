
/****************************************************************************/
//PROJECT :CAREER COUNCELLING - A STEP TOWARDS BETTER FUTURE//
/****************************************************************************/
//PASSWORD:pcc or PCC//
/****************************************************************************/

//INCLUDING HEADER FILES//

#include<graphics.h>
#include<stdio.h>
#include<conio.h>
#include<dos.h>
#include<fstream.h>
#include<string.h>
#include<ctype.h>
#include<process.h>

/****************************************************************************/
//CLASS NAME: career//
//DETAILS: It Controls Over All The Functions//
/****************************************************************************/

class career
{
public:
void Register();
void Aim();
void Performa();
void Password();
void line_hor(int,int,int,char);
void line_ver(int,int,int,char);
void box_password(void);
void informations();
void display();
void start();
void menu();
void colleges();
void acknow();
void end();
void sm();
void commerce();
void arts();
void profile();
void eo();
void ce();
void medical();
void nonmed();
void misc1();
void inst();
};

/****************************************************************************/
//CLASS NAME: career//
//FUNCTION NAME: line_hor()//
//DETAILS: It accepts rows & columns &draw a horizontal line //
/****************************************************************************/

void career::line_hor(int column1,int column2,int row,char c)
{
for(column1;column1<=column2;column1++)
{
gotoxy(column1,row);
cout<<c;
}
}

/****************************************************************************/
//CLASS NAME: career//
//FUNCTION NAME: line_ver()//
//DETAILS: It accepts rows & columns &draw a vertical line //
/****************************************************************************/

void career::line_ver(int row1,int row2,int column,char c)
{
for(row1;row1<=row2;row1++)
{
gotoxy(column,row1);
cout<<c;
}
}

/****************************************************************************/
//CLASS NAME: career//
//FUNCTION NAME: start()//
//DETAILS: It starts the project in graphics mode //
/****************************************************************************/

void career::start()
{
clrscr();
int gd=DETECT;
int gm;
initgraph(&gd,&gm,"..\\bgi");
int co=0;
int r,r1;
int i=0;
for(r=33;r<600;r++)
{ r1=r;
 r1-=50;
 i=r1-3;
if(co==16)
 co=1;
setcolor(1);
co++;
setcolor(LIGHTRED);
circle(320,240,r1++);
{
setcolor(BLACK+BLINK);
settextstyle(1,0,6);
outtextxy(50,100,"PROJECT :");
outtextxy(50,200,"CAREER COUNCELLING");
settextstyle(1,0,4);
outtextxy(30,300,"A STEP TOWARDS BETTER FUTURE . . .");
outtextxy(1,325,"---------------------------------------------------------------------------------------------------------------------------");
}
}
for(r=600;r>33;r--)
{ r1=r;
  r1-=50;
 i=r1-3;
if(co==16)
 co=1;
co++;
circle(320,240,r1++);
}
delay(500);
cleardevice();
closegraph();
}

/****************************************************************************/
//CLASS NAME: career//
//FUNCTION NAME: box_password()//
//DETAILS: It draws the box for password //
/****************************************************************************/

void career::box_password(void)
{
int counter;
for(counter=16;counter<=66;counter++)
{
gotoxy(counter,21);
cout<<"#@#";
sound(100+(10*counter));
delay(10);
}nosound();
for(counter=16;counter<=66;counter++)
{
gotoxy(counter,4);
cout<<"#@#";
sound(100+(10*counter));
delay(10);
}nosound();
for(counter=4;counter<=21;counter++)
{
gotoxy(16,counter);
cout<<"#@#";
sound(100+(10*counter));
delay(10);
}nosound();
 for(counter=4;counter<=21;counter++)
{
gotoxy(66,counter);
cout<<"#@#";
sound(100+(10*counter));
delay(10);
}nosound();
for(counter=16;counter<=66;counter++)
{
gotoxy(counter,21);
cout<<"#@#";
sound(100+(10*counter));
delay(10);
}nosound();
for(counter=16;counter<=70;counter++)
{
sound(100+(10*counter));
delay(10);
}nosound();
}

/****************************************************************************/
//CLASS NAME: career//
//FUNCTION NAME: Password()//
//DETAILS: It accepts the password &continues the execution if correct entered //
/****************************************************************************/

void career::Password()
{int counter;
clrscr();
char pass1,pass2,pass3;
box_password();
gotoxy(30,11);
cout<<"Enter the password";
pass1=getch();
cout<<"*";
pass2=getch();
cout<<"*";
pass3=getch();
cout<<"*";
sound(500);
delay(100);
nosound();
if((pass1=='p'&&pass2=='c'&&pass3=='c')||(pass1=='P'&&pass2=='C'&&pass3=='C'))
	{
		return;
		for(counter=16;counter<=166;counter++)
		{
		sound(100+(10*counter));
		delay(10);
		}nosound();
		}
	else
		gotoxy(30,12);
		cout<<"Wrong password";
for(counter=16;counter<=166;counter++)
{
sound(100+(10*counter));
delay(10);
}nosound();
	exit(0);
	}

/****************************************************************************/
//CLASS NAME: career//
//FUNCTION NAME: informations()//
//DETAILS: It tells the user to fill the informations //
/****************************************************************************/

void career::informations()
{ int graphdriver = DETECT,graphmode,errorcode;
initgraph(&graphdriver, &graphmode, "..//bgi");
int  a=10,b=15,c=635,d=455;
for(int i=0;i<25;i++)
{ setcolor(i);
rectangle(a,b,c,d);
a+=3;
b+=3;
c-=3;
d-=3;
delay(100);
sound(500);
delay(70);
nosound();
}
setcolor(YELLOW);
settextstyle(1,0,3);
outtextxy(150,180,"PLEASE FILL THE FOLLOWING");
outtextxy(220,220," INFORMATIONS :");
delay(3000);
cleardevice();
closegraph();
 }

/****************************************************************************/
//CLASS NAME: career//
//FUNCTION NAME: Performa()//
//DETAILS: It accepts the information about the user //
/****************************************************************************/

void career::Performa()
{
textcolor(LIGHTGREEN);
clrscr();
char name[20],fname[20],inst[30],board1[10],achieve[30],achieve1[30],area[10],interest[20];
float y;
int counter,valid;
for(counter=2;counter<=76;counter++)
{
gotoxy(counter,25);
cout<<"#";
sound(100+(10*counter));
delay(10);
}nosound();
 for(counter=2;counter<=76;counter++)
{
gotoxy(counter,1);
cout<<"#";
sound(100+(10*counter));
delay(10);
}nosound();
for(counter=1;counter<=25;counter++)
{
gotoxy(1,counter);
cout<<"#";
sound(100+(10*counter));
delay(10);
}nosound();
 for(counter=1;counter<=25;counter++)
{
gotoxy(77,counter);
cout<<"#";
sound(100+(10*counter));
delay(10);
}nosound();
for(counter=16;counter<=66;counter++)
textcolor(LIGHTGREEN);
gotoxy(5,2);
cout<<"NAME:";
textcolor(CYAN);
gets(name);
textcolor(LIGHTGREEN);
gotoxy(5,4);
cout<<"FATHER's NAME:";
textcolor(CYAN);
gets(fname);
textcolor(LIGHTGREEN);
gotoxy(5,6);
cout<<"NAME OF THE INSTITUTION IN WHICH YOU ARE STUDYING :";
textcolor(LIGHTGREEN);
gets(inst);
gotoxy(5,8);
cout<<"PERCENTAGE OF MARKS IN X BOARD:";
cin>>y;
gotoxy(5,10);
cout<<"BOARD FROM WHICH YOU HAVE PASSED CLASS X/XII:";
gets(board1);
gotoxy(5,12);
cout<<"YOUR STREAM (Science/Commerce/Humanities):";
gets(area);
textcolor(LIGHTGREEN);
gotoxy(5,14);
cout<<"ANY ACADEMIC ACHIEVEMENT:";
textcolor(LIGHTGREEN);
gets(achieve);
textcolor(LIGHTGREEN);
gotoxy(5,16);
cout<<"ANY CULTURAL/SOCIAL ACHIEVEMENT:";
textcolor(LIGHTGREEN);
gets(achieve1);
textcolor(LIGHTGREEN);
gotoxy(5,18);
cout<<"AREA OF INTEREST(North/South/East/West):";
textcolor(LIGHTGREEN);
gets(interest);
clrscr();
{
clrscr();
box_password();
char msg[100],*p;
textcolor(YELLOW);
sprintf(msg,"HELLO %s",name);
gotoxy(30,10);
cout<<msg;
gotoxy(4,23);
cout<<" < PRESS ANY KEY TO CONTINUE >";
getch();
}
}

/****************************************************************************/
//CLASS NAME: career//
//FUNCTION NAME: inst()//
//DETAILS: It displays certain instructions for user //
/****************************************************************************/

void career::inst()
{
textcolor(LIGHTGREEN);
clrscr();
int counter,valid;
for(counter=2;counter<=76;counter++)
{
gotoxy(counter,20);
cout<<"#";
sound(100+(10*counter));
delay(10);
}nosound();
 for(counter=2;counter<=76;counter++)
{
gotoxy(counter,8);
cout<<"#";
sound(100+(10*counter));
delay(10);
}nosound();
for(counter=8;counter<=20;counter++)
{
gotoxy(1,counter);
cout<<"#";
sound(100+(10*counter));
delay(10);
}nosound();
 for(counter=8;counter<=20;counter++)
{
gotoxy(77,counter);
cout<<"#";
sound(100+(10*counter));
delay(10);
}nosound(); for(counter=16;counter<=66;counter++)
textcolor(LIGHTGREEN);
gotoxy(5,10);
cout<<"INSTRUCTION TO USER:";
gotoxy(3,12);
cout<<"It is hereby notified that we are just giving useful informations about";
gotoxy(3,14);
cout<<"the various institutions.For further details,viz information about various";
gotoxy(3,16);
cout<<"courses offered by the institution,the concerned fees, kindly contact ";
gotoxy(3,18);
cout<<"the respective colleges and institution in person or in writing.";
gotoxy(4,23);
cout<<"< PRESS ANY KEY TO CONTINUE >";
getch();
}


/****************************************************************************/
//CLASS NAME: career//
//FUNCTION NAME: Aim()//
//DETAILS: It displays the aim of the project //
/****************************************************************************/

void career::Aim()
{
clrscr();
int midx,midy,size,style;
char CENTRE_TEXT;
int graphdriver = DETECT,graphmode,errorcode;
initgraph(&graphdriver, &graphmode, "..//bgi");
cleardevice();
midx = getmaxx()/2;
midy = getmaxy()/2;
cleardevice();
settextjustify(CENTRE_TEXT,CENTER_TEXT);
int  q=5,w=10,e=630,r=450;
for(int t=9;t<13;t++)
{ setcolor(t);
rectangle(q,w,e,r);
q+=3;
w+=3;
e-=3;
r-=3;
delay(100);
sound(500);
delay(100);
nosound();
}
settextstyle(1,0,5);
setcolor(YELLOW);
outtextxy(40,150,"THE AIM OF THE SOFTWARE");
outtextxy(40,200,"IS :");
delay(3000);
cleardevice();
int  a=5,b=10,c=630,d=450;
for(int i=9;i<=13;i++)
{ setcolor(i);
rectangle(a,b,c,d);
a+=3;
b+=3;
c-=3;
d-=3;
delay(100);
sound(500);
delay(50);
nosound();
}
style = 3;
size =6;
setcolor(12);
settextstyle(style,HORIZ_DIR,size);
outtextxy(35,30,"AIM :");
delay(450);
sound(500);
delay(100);
nosound();
settextstyle(1,0,3);
sound(500);
delay(100);
nosound();
outtextxy(25,90,"The purpose of this software is to tell class XII");
delay(450);
sound(500);
delay(100);
nosound();
outtextxy(25,115,"students that what they can do after class XII,");
delay(450);
sound(500);
delay(100);
nosound();
outtextxy(25,144,"to which college they can take admission & which   ");
delay(450);
sound(500);
delay(100);
nosound();
outtextxy(25,167,"subject they can opt for.");
delay(450);
sound(500);
delay(100);
nosound();
outtextxy(25,190,"This software also help them to know about the ");
delay(450);
sound(500);
delay(100);
nosound();
outtextxy(25,214,"percentage marks which different colleges require. ");
delay(450);
sound(500);
delay(100);
nosound();
outtextxy(25,236,"This software also tells about the location & ");
delay(450);
sound(500);
delay(100);
nosound();
outtextxy(25,258,"fees of different colleges.This software also give ");
delay(450);
sound(500);
delay(100);
nosound();
outtextxy(25,282,"the facility to students to know about different ");
delay(450);
sound(500);
delay(100);
nosound();
outtextxy(25,307,"colleges in particular area in which they want to  ");
delay(450);
sound(500);
delay(100);
nosound();
outtextxy(25,330,"take admission.");
delay(450);
sound(500);
delay(100);
nosound();
outtextxy(25,352,"This software will be very helpful for class XII ");
delay(450);
sound(500);
delay(100);
nosound();
outtextxy(25,371,"students to remove doubts from their minds ");
delay(450);
sound(500);
delay(100);
nosound();
outtextxy(25,390,"about their career.");
sound(500);
delay(100);
nosound();
delay(4000);
cleardevice();
int  z=10,x=15,v=635,n=455;
for(int s=0;s<17;s++)
{ setcolor(s);
rectangle(z,x,v,n);
z+=3;
x+=3;
v-=3;
n-=3;
delay(100);
sound(500);
delay(70);
nosound();
}
setcolor(YELLOW);
settextstyle(1,0,4);
outtextxy(80,180,"PLEASE SELECT THE OPTION");
outtextxy(80,230,"BY PRESSING ASSOCIATED");
outtextxy(80,280,"NUMBER :");
delay(3000);
cleardevice();
closegraph();
}

/****************************************************************************/
//CLASS NAME: career//
//FUNCTION NAME: menu()//
//DETAILS: It displays the main menu //
/****************************************************************************/

void career::menu()
{
int opt1;
int graphdriver = DETECT,graphmode,errorcode;
initgraph(&graphdriver, &graphmode, "..//bgi");
int co=0;
int r,r1;
int i=0;
int j=0;
for(r=600;r>33;r--)
{ r1=r;
for(int d=0;d<=1;d++)
 r1-=50;
 i=r1-3;
if(co==16)
 co=1;
setcolor(1);
co++;
setcolor(CYAN);
circle(320,240,r1++);
}
char ch;
again:
setcolor(BLACK);
settextstyle(1,0,6);
outtextxy(140,20,"MAIN - MENU");
settextstyle(1,0,4);
outtextxy(20,100,"1: SCIENCE STREAM");
outtextxy(20,140,"2: COMMERCE STREAM");
outtextxy(20,180,"3: ARTS STREAM");
outtextxy(20,220,"4: COLLEGES AT GLANCE");
outtextxy(20,260,"5: UNIVERSITY PROFILE");
outtextxy(20,300,"6: COMPUTER EDUCATION");
outtextxy(20,340,"7: MISCELLANEOUS EDUCATION OPTIONS");
settextstyle(1,0,4);
outtextxy(120,420,"ENTER YOUR CHOICE...");
outtextxy(20,380,"0: EXIT TO DOS ");
ch = getch() ;

		if ( ch == '1' )
		{
		sm();
		}
		else
		if ( ch =='2' )
		{
		 cleardevice();
		 closegraph();
		 commerce();
		}
		else
		if ( ch == '3' )
		{
		 cleardevice();
		 closegraph();
		arts();
		}
		else
		if ( ch == '4')
		{
		 cleardevice();
		 closegraph();
		colleges();
		}
		else
		if(ch=='5')
		{
		cleardevice();
		closegraph();
		profile();
		}
		else
		if(ch=='6')
		{
		cleardevice();
		closegraph();
		ce();
		}
		else
		if(ch=='7')
		{
		cleardevice();
		closegraph();
		eo();
		}
		else
		if ( ch =='0' )
		{
		cleardevice();
		closegraph();
		acknow();
		}
}

/****************************************************************************/
//CLASS NAME: career//
//FUNCTION NAME: sm()//
//DETAILS: It displays the science menu when user press 1 in the main menu //
/****************************************************************************/

void career::sm()
{
int co=0;
int r,r1;
int i=0;
int j=0;
for(r=33;r<600;r++)
{ r1=r;
for(int d=0;d<=1;d++)
 r1-=50;
 i=r1-3;
if(co==16)
 co=1;
setcolor(1);
co++;
setcolor(LIGHTGREEN);
circle(320,240,r1++);
}
{
char ch;
again:
setcolor(BLACK);
settextstyle(1,0,6);
outtextxy(110,20,"SCIENCE - MENU");
settextstyle(1,0,4);
outtextxy(10,100,"1: MEDICAL");
outtextxy(10,140,"2: NON-MEDICAL");
outtextxy(10,180,"3: MISCELLANEOUS EDUCATION OPTION");
outtextxy(10,220,"0: RETURN");
settextstyle(1,0,4);
outtextxy(50,300,"ENTER YOUR CHOICE...");
ch = getch() ;
if (ch=='1')
{
cleardevice();
closegraph();
medical();
}
else  if (ch == '2')
{
cleardevice();
closegraph();
nonmed();
}
else  if (ch == '3')
{
cleardevice();
closegraph();
misc1();
}
else  if (ch == '0')
{
cleardevice();
closegraph();
menu();
}
}
}

/****************************************************************************/
//CLASS NAME: career//
//FUNCTION NAME: medical()//
//DETAILS: It displays information about medical education option //
/****************************************************************************/

void career::medical()
{
char ch;
int graphdriver = DETECT,graphmode,errorcode;
initgraph(&graphdriver, &graphmode, "..//bgi");
settextstyle(1,0,3);
setcolor(LIGHTBLUE);
delay(350);
sound(500);
delay(100);
nosound();
outtextxy(10,30,"-EDUCATION CENTRES FOR MEDICAL STUDENTS - ");
delay(350);
sound(500);
delay(100);
nosound();
outtextxy(10,55,"1:  All India Instiute For Medical Sciences ");
delay(350);
sound(500);
delay(100);
nosound();
outtextxy(10,85,"2:  Maulana Azad Medical College ");
delay(400);
sound(500);
delay(100);
nosound();
outtextxy(10,115,"3:  Lady Hardinge Medical College  ");
delay(400);
sound(500);
delay(100);
nosound();
outtextxy(10,145,"4:  Ayurvedic And Unani Tibbia College  ");
delay(400);
sound(500);
delay(100);
nosound();
outtextxy(10,175,"5:  Universities Collegee Of Medical Sciences ");
delay(400);
sound(500);
delay(100);
nosound();
delay(400);
setcolor(12+128);
settextstyle(1,0,1);
rectangle(1,460,630,400);
outtextxy(10,400,"PRESS <Esc> TO RETURN TO MAIN MENU");
outtextxy(10,417,"PRESS ASSOCIATED No.TO KNOW MORE ABOUT GIVEN INSTIT.");
outtextxy(10,435,"ENTER YOUR CHOICE:");
ch=getch();
{
cleardevice();
closegraph();
}
if(ch=='1')
{
clrscr();
textcolor(CYAN);
gotoxy(1,1);
cout<<" All India Institute of Medical Sciences ";
textcolor(YELLOW);
gotoxy(1,3);
cout<<" Ansari Nagar,New Delhi-110029  ";
gotoxy(1,4);
cout<<"Tele: 6564851,6561123  Fax: 6862663 ";
gotoxy(1,5);
cout<<"E-mail: pkdave@medinst.ernet.in  ";
textcolor(CYAN);
gotoxy(1,7);
cout<<"INSTITUTIONAL PROFILE:";
textcolor(YELLOW);
gotoxy(1,8);
cout<<" AIIMS was established in 1956 as an autonoums body with the objective of ";
gotoxy(1,9);
cout<<"developing programmes of medicaal education and patterns of teaching in under  ";
gotoxy(1,10);
cout<<"graduate aand post graduatemedical education to all medical colleges and allied  ";
gotoxy(1,11);
cout<<"institutions in INDIA. The instiute provides the best possible education ";
gotoxy(1,12);
cout<<"facilities for the training of personnel in all the branches of health ";
gotoxy(1,13);
cout<<" activities. ";
textcolor(CYAN);
gotoxy(1,15);
cout<<"INFRASTRUCTURAL FACILITIES:";
textcolor(YELLOW);
gotoxy(1,16);
cout<<"- The institute has well stocked LIBRARY. ";
gotoxy(1,17);
cout<<"- The instute has seprate HOSTELS for girls,boys and also for maarried doctors. ";
gotoxy(1,18);
cout<<"- The instiute has six centres of RESEARCH ";
textcolor(CYAN);
gotoxy(1,21);
cout<<"COURSES:";
textcolor(YELLOW);
gotoxy(1,22);
cout<<"Graduate Courses:- five and a haalf years MBBS course and selection on the  ";
gotoxy(1,23);
cout<<"basis of all india entrance test ";
textcolor(CYAN);
gotoxy(1,24);
cout<<"< PRESS ANY KEY TO CONTINUE >";
getch();
clrscr();
textcolor(YELLOW);
gotoxy(1,1);
cout<<"-Para medical courses:- ";
gotoxy(1,2);
cout<<"(i) Three year B.SC hons.(opthalmic techniques/speech and  ";
gotoxy(1,3);
cout<<"hearing/ medical tech in radiotherapy).    ";
gotoxy(1,5);
cout<<"(ii) Three year MD/MS. ";
gotoxy(1,6);
cout<<"(iii) Two year DM/MCH/PhD after post graduation.  ";
gotoxy(1,7);
cout<<"(iv) Two year M.Sc(anatomy/biochemistry/biophysics/physiology/pharmacology)   ";
gotoxy(1,8);
cout<<"(v) Two year M.Sc(drug assay). ";
textcolor(CYAN);
gotoxy(1,10);
cout<<"(vi) Two year master of bio-technology. ";
textcolor(YELLOW);
gotoxy(1,11);
cout<<"(vii) Two years masters in hospital administration. ";
gotoxy(1,12);
cout<<" FEES:- Fees varies from course to course. ";
gotoxy(1,13);
cout<<"TOTAL NO. OF ENROLLED STUDENTS :- 275  ";
textcolor(CYAN);
gotoxy(1,24);
cout<<"< PRESS ANY KEY TO RETURN TO MEDICAL COLLEGES MENU >";
getch();
medical();
sound(500);
delay(100);
nosound();
}
else if(ch=='2')
{
clrscr();
textcolor(CYAN);
gotoxy(1,1);
cout<<" MAULANA AZAD MEDICAL COLLEGE ";
textcolor(YELLOW);
gotoxy(1,3);
cout<<" Bahadur Shah Zafar Marg,  New Delhi-110002  ";
gotoxy(1,4);
cout<<"Tele: 3239271   ";
gotoxy(1,5);
cout<<"Fax: 3235574  ";
textcolor(CYAN);
gotoxy(1,7);
cout<<"INSTITUTIONAL PROFILE:";
textcolor(YELLOW);
gotoxy(1,8);
cout<<" MAMC consist of four integral units,namely,Maulana azad medical college, ";
gotoxy(1,9);
cout<<"Lok nayak hospital,Govind ballabh pant hospital,Guru nanak eye ccentre.The   ";
gotoxy(1,10);
cout<<"college was established 22 years aafter the commisioning of Irwin commision.";
gotoxy(1,11);
cout<<"This ideally situated Irwin hospital with long years of reputation paved ";
gotoxy(1,12);
cout<<"the way for this medical college.A seprate dental wing was set up in the ";
gotoxy(1,13);
cout<<" year 1983. ";
textcolor(CYAN);
gotoxy(1,15);
cout<<"INFRASTRUCTURAL FACILITIES:";
textcolor(YELLOW);
gotoxy(1,16);
cout<<"- The institute has well stocked LIBRARY. ";
gotoxy(1,17);
cout<<"- The instute has seprate HOSTELS for girls and boys.  ";
textcolor(CYAN);
gotoxy(1,21);
cout<<"COURSES:";
textcolor(YELLOW);
gotoxy(1,22);
cout<<" Under graduate and post graduate degree and diploma in medicine and  ";
gotoxy(1,23);
cout<<" dentistry. ";
textcolor(CYAN);
gotoxy(1,24);
cout<<"< PRESS ANY KEY TO CONTINUE >";
getch();
clrscr();
textcolor(YELLOW);
gotoxy(1,12);
cout<<" FEES:- Fees varies from course to course. ";
gotoxy(1,14);
cout<<"TOTAL NO. OF ENROLLED STUDENTS :-";
gotoxy(1,15);
cout<<" MBBS-94 male ,86 female; ";
gotoxy(1,16);
cout<<"BDS-8 male,12 female";
textcolor(CYAN);
gotoxy(1,24);
cout<<"< PRESS ANY KEY TO RETURN TO MEDICAL COLLEGES MENU >";
getch();
medical();
sound(500);
delay(100);
nosound();
}
else if (ch=='3')
{
clrscr();
textcolor(CYAN);
gotoxy(1,1);
cout<<" LADY HARDINGE MEDICAL COLLEGE ";
textcolor(YELLOW);
gotoxy(1,3);
cout<<" Cannaught Place ,  New Delhi-110001  ";
textcolor(CYAN);
gotoxy(1,5);
cout<<"INSTITUTIONAL PROFILE:";
textcolor(YELLOW);
gotoxy(1,7);
cout<<"Lady hardinge medical college was established in 1949 ";
textcolor(CYAN);
gotoxy(1,10);
cout<<"INFRASTRUCTURAL FACILITIES:";
textcolor(YELLOW);
gotoxy(1,12);
cout<<"- The institute has well stocked LIBRARY. ";
gotoxy(1,14);
cout<<"- The instute has seprate HOSTELS for girls and boys.  ";
textcolor(CYAN);
gotoxy(1,16);
cout<<"COURSES:";
textcolor(YELLOW);
gotoxy(1,18);
cout<<" MBBS,MD,MS,MSc,DCH,DA,PhD.  ";
gotoxy(1,20);
cout<<" FEES:- Fees varies from course to course. ";
gotoxy(1,22);
cout<<"TOTAL NO. OF ENROLLED STUDENTS :- 802 ";
textcolor(CYAN);
gotoxy(1,24);
cout<<"< PRESS ANY KEY TO RETURN TO MEDICAL COLLEGES MENU >";
getch();
medical();
sound(500);
delay(100);
nosound();
}
else if(ch=='4')
{
clrscr();
textcolor(CYAN);
gotoxy(1,1);
cout<<" AYURVEDIC AND UNANI TIBBIA COLLEGE ";
textcolor(YELLOW);
gotoxy(1,3);
cout<<"   New Delhi-110005  ";
textcolor(CYAN);
gotoxy(1,5);
cout<<"INSTITUTIONAL PROFILE:";
textcolor(YELLOW);
gotoxy(1,7);
cout<<"Ayurvedic and unani tibbia college was established in 1974 ";
textcolor(CYAN);
gotoxy(1,10);
cout<<"INFRASTRUCTURAL FACILITIES:";
textcolor(YELLOW);
gotoxy(1,12);
cout<<"- The institute has well stocked LIBRARY. ";
gotoxy(1,14);
cout<<"- The instute has seprate HOSTELS for girls and boys.  ";
textcolor(CYAN);
gotoxy(1,16);
cout<<"COURSES:";
textcolor(YELLOW);
gotoxy(1,18);
cout<<" pre-tibb,BAMS,BUMS.  ";
gotoxy(1,20);
cout<<" FEES:- Fees varies from course to course. ";
gotoxy(1,22);
cout<<"TOTAL NO. OF ENROLLED STUDENTS :- 306 ";
textcolor(CYAN);
gotoxy(1,24);
cout<<"< PRESS ANY KEY TO RETURN TO MEDICAL COLLEGES MENU >";
getch();
medical();
sound(500);
delay(100);
nosound();
}
else if(ch=='5')
{
clrscr();
textcolor(CYAN);
gotoxy(1,1);
cout<<" UNIVERSITY  COLLEGE OF MEDICAL SCIENCES  ";
textcolor(YELLOW);
gotoxy(1,3);
cout<<"   New Delhi-110095  ";
textcolor(CYAN);
gotoxy(1,7);
cout<<"INSTITUTIONAL PROFILE:";
textcolor(YELLOW);
gotoxy(1,8);
cout<<"University college of medical sciences was established in 1971 ";
textcolor(CYAN);
gotoxy(1,10);
cout<<"INFRASTRUCTURAL FACILITIES:";
textcolor(YELLOW);
gotoxy(1,12);
cout<<"- The institute has well stocked LIBRARY. ";
gotoxy(1,14);
cout<<"- The instute has seprate HOSTELS for girls and boys.  ";
textcolor(CYAN);
gotoxy(1,16);
cout<<"COURSES:";
textcolor(YELLOW);
gotoxy(1,18);
cout<<" MBBS,B.Sc(MT)Radiography,PG   ";
gotoxy(1,20);
cout<<" FEES:- Fees varies from course to course. ";
gotoxy(1,22);
cout<<"TOTAL NO. OF ENROLLED STUDENTS :- 306 ";
textcolor(CYAN);
gotoxy(1,24);
cout<<"< PRESS ANY KEY TO RETURN TO MEDICAL COLLEGES MENU >";
getch();
medical();
sound(500);
delay(100);
nosound();
}
else if(ch==27)
{
menu();
}
}

/****************************************************************************/
//CLASS NAME: career//
//FUNCTION NAME: nonmed()//
//DETAILS: It displays information about non medical education option //
/****************************************************************************/

void career::nonmed()
{
char ch;
int graphdriver = DETECT,graphmode,errorcode;
initgraph(&graphdriver, &graphmode, "..//bgi");
settextstyle(1,0,3);
setcolor(LIGHTBLUE);
delay(350);
outtextxy(10,30,"-EDUCATION CENTRES FOR NON-MEDICAL STUDENTS - ");
delay(350);
sound(500);
delay(100);
nosound();
outtextxy(10,55,"1: Indian Instiutes of Technology ");
delay(350);
sound(500);
delay(100);
nosound();
outtextxy(10,85,"2: University Of Roorkee ");
delay(400);
sound(500);
delay(100);
nosound();
outtextxy(10,115,"3: Birla Instutute Of Technology,Ranchi. ");
delay(400);
sound(500);
delay(100);
nosound();
outtextxy(10,145,"4: Regional Engeering Colleges  ");
delay(400);
sound(500);
delay(100);
nosound();
outtextxy(10,175,"5: Indian Institute Of Science, Banglore ");
delay(400);
sound(500);
delay(100);
nosound();
outtextxy(10,205,"6: Karnataka Engeeneering Colleges ");
delay(400);
setcolor(12+128);
settextstyle(1,0,1);
rectangle(1,460,630,400);
outtextxy(10,400,"PRESS <Esc> TO RETURN TO MAIN MENU");
outtextxy(10,417,"PRESS ASSOCIATED No.TO KNOW MORE ABOUT GIVEN INSTIT.");
outtextxy(10,435,"ENTER YOUR CHOICE:");
ch=getch();
{
cleardevice();
closegraph();
}
if(ch=='1')
{
clrscr();
textcolor(CYAN);
gotoxy(1,1);
cout<<"  Indian Institutes of Technology ";
textcolor(YELLOW);
gotoxy(1,3);
cout<<" Various Centres At Delhi,Kanpur,Mumbai,Kharagpur,Chennai,Guwahati,B.H.U., ";
gotoxy(1,4);
cout<<"Varanasi andI.I.M.,Dhanbad.";
textcolor(CYAN);
gotoxy(1,10);
cout<<" FEES:- Fees varies from course to course. ";
gotoxy(1,13);
cout<<"TOTAL NO. OF ENROLLED STUDENTS :- approx. 2500 candidates through a two";
gotoxy(1,14);
cout<<"stage entrance  exam held all over the country." ;
gotoxy(1,24);
cout<<"< PRESS ANY KEY TO RETURN TO NON MEDICAL COLLEGES MENU >";
getch();
nonmed();
sound(500);
delay(100);
nosound();
}
else
if(ch=='2')
{
clrscr();
textcolor(CYAN);
gotoxy(1,1);
cout<<"  University of Roorkee ";
textcolor(YELLOW);
gotoxy(1,6);
cout<<" FEES:- Fees varies from course to course. ";
gotoxy(1,4);
cout<<"TOTAL NO. OF ENROLLED STUDENTS :- approx. 2500 candidates through a two";
gotoxy(1,5);
cout<<"stage entrance  exam held all over the country.";
gotoxy(1,24);
cout<<"< PRESS ANY KEY TO RETURN TO NON MEDICAL COLLEGES MENU >";
getch();
nonmed();
sound(500);
delay(100);
nosound();
}
else
if(ch=='3')
{
clrscr();
textcolor(CYAN);
gotoxy(1,1);
cout<<"  Birla Institute of Technology,Ranchi ";
textcolor(YELLOW);
gotoxy(1,6);
cout<<"It offers various four and five year courses in varied fields of engineering. ";
gotoxy(1,4);
cout<<"TOTAL NO. OF ENROLLED STUDENTS :- approx. 2500 candidates through an";
gotoxy(1,5);
cout<<"all-India entrance  exam held all over the country.";
gotoxy(1,24);
cout<<"< PRESS ANY KEY TO RETURN TO NON MEDICAL COLLEGES MENU >";
getch();
nonmed();
sound(500);
delay(100);
nosound();
}
else
if(ch=='4')
{
clrscr();
textcolor(CYAN);
gotoxy(1,1);
cout<<"  Regional Engineering Colleges at Kurukshetra,Allahbad,Nagpur and Jaipur. ";
textcolor(YELLOW);
gotoxy(1,6);
cout<<"They offer various four and five year courses in varied fields of engineering. ";
gotoxy(1,4);
cout<<"TOTAL NO. OF ENROLLED STUDENTS :- approx. 2500 candidates(each) through an";
gotoxy(1,5);
cout<<"all-India entrance exam held all over the country.";
gotoxy(1,24);
cout<<"< PRESS ANY KEY TO RETURN TO NON MEDICAL COLLEGES MENU >";
getch();
nonmed();
sound(500);
delay(100);
nosound();
}
else
if(ch=='5')
{
clrscr();
textcolor(CYAN);
gotoxy(1,1);
cout<<"  Indian Institute Of Science,Bangalore. ";
textcolor(YELLOW);
gotoxy(1,3);
cout<<"It offers four year course in M.E. ";
gotoxy(1,6);
cout<<"ELIGIBILITY:  B.Sc with PCM";
gotoxy(1,5);
cout<<"An  all-India entrance exam is held in the country in physics and maths in April .";
gotoxy(1,24);
cout<<"< PRESS ANY KEY TO RETURN TO NON MEDICAL COLLEGES MENU >";
getch();
nonmed();
sound(500);
delay(100);
nosound();
}
else
if(ch=='6')
{
clrscr();
textcolor(CYAN);
gotoxy(1,1);
cout<<" Karnataka Engineering Colleges";
textcolor(YELLOW);
gotoxy(1,3);
cout<<"They offer various four and five year courses in varied fields of engineering. ";
gotoxy(1,6);
cout<<"ELIGIBILITY:  Marks in 10+2 exam";
gotoxy(1,5);
cout<<"An  all-India entrance exam is held in the country in April ." ;
gotoxy(1,24);
cout<<"< PRESS ANY KEY TO RETURN TO NON MEDICAL COLLEGES MENU >";
getch();
nonmed();
sound(500);
delay(100);
nosound();
}
else
if(ch==27)
{
menu();
}
}

/****************************************************************************/
//CLASS NAME: career//
//FUNCTION NAME: misc1()//
//DETAILS: It gives cutoff list of various colleges providing education in //
//            field of science //
/****************************************************************************/

void career::misc1()
{
int graphdriver = DETECT,graphmode,errorcode;
int midx,midy;
int xmax,ymax;
initgraph(&graphdriver, &graphmode,"..\\bgi");
errorcode = graphresult();
if (errorcode!=grOk)
{
printf("graphics error:%s\n",grapherrormsg(errorcode));
printf("press any key to halt:");
getch();
exit(1);
}
setcolor(getmaxcolor());
xmax = getmaxx();
ymax = getmaxy();
settextstyle(1,0,3);
outtextxy(25,90,"THE SCREEN APPEARING NEXT WILL SHOW YOU THE  ");
delay(150);
outtextxy(25,115,"CUT OFF LIST OF VARIOUS COLLEGES PROVIDING ");
delay(150);
outtextxy(25,144,"EDUCATION IN THE FIELD OF SCIENCE.    ");
delay(3500);
cleardevice();
line(1,70,600,70);
line(1,90,600,90);
line(1,110,600,110);
line(1,130,600,130);
line(1,150,600,150);
line(1,170,600,170);
line(1,190,600,190);
line(1,210,600,210);
line(1,230,600,230);
line(1,250,600,250);
line(1,270,600,270);
line(1,290,600,290);
line(1,310,600,310);
line(1,330,600,330);
line(1,350,600,350);
line(1,370,600,370);
line(1,70,1,370);
line(98,90,98,370);
line(140,90,140,370);
line(190,90,190,370);
line(254,90,254,370);
line(310,90,310,370);
line(390,90,390,370);
line(450,90,450,370);
line(500,90,500,370);
line(600,70,600,370);
delay(1000);
settextstyle(1,0,1);
outtextxy(200,70," B.SC (HONS) COURSES");
delay(1000);
outtextxy(5,90,"COLLEGES");
outtextxy(99,90,"PHY");
outtextxy(142,90,"CHEM");
outtextxy(194,90,"MATHS");
outtextxy(257,90,"ZOOL");
outtextxy(312,90,"ELECTRO");
outtextxy(391,90,"STATS");
outtextxy(452,90,"BOT");
outtextxy(505,90,"BIO CHEM");
outtextxy(5,110,"HANSRAJ");
outtextxy(92,110," 81.3");
outtextxy(144,110," 76");
outtextxy(194,110," 84.5");
outtextxy(260,110," 74");
outtextxy(312,110," 86.6");
outtextxy(405,110," -");
outtextxy(455,110," 79");
outtextxy(525,110," -");
outtextxy(5,130,"HINDU");
outtextxy(92,130," 85");
outtextxy(144,130," 79");
outtextxy(194,130," 83");
outtextxy(260,130," 79");
outtextxy(312,130,"  -");
outtextxy(405,130,"75.5");
outtextxy(455,130," 76");
outtextxy(525,130," -");
outtextxy(5,150,"PGDAV");
outtextxy(92,150," -");
outtextxy(144,150," -");
outtextxy(194,150," -");
outtextxy(260,150," -");
outtextxy(312,150," -");
outtextxy(405,150," 65");
outtextxy(455,150," -");
outtextxy(525,150," -");
outtextxy(5,170,"AGARSAIN");
outtextxy(92,170, " -");
outtextxy(144,170," -");
outtextxy(194,170," -");
outtextxy(260,170," -");
outtextxy(312,170," -");
outtextxy(405,170," -");
outtextxy(455,170," 76");
outtextxy(525,170," -");
outtextxy(5,190,"SHYAMLAL");
outtextxy(92,190, " -");
outtextxy(144,190," -");
outtextxy(194,190," -");
outtextxy(260,190," -");
outtextxy(312,190," 76");
outtextxy(405,190," -");
outtextxy(455,190," -");
outtextxy(525,190," -");
outtextxy(5,210,"KALINDI");
outtextxy(92,210, " 65");
outtextxy(144,210," -");
outtextxy(194,210," 66");
outtextxy(260,210," -");
outtextxy(312,210," -");
outtextxy(405,210," -");
outtextxy(455,210," -");
outtextxy(525,210," -");
outtextxy(5,230,"STEPHENS");
outtextxy(92,230, " -");
outtextxy(144,230," -");
outtextxy(194,230," -");
outtextxy(260,230," -");
outtextxy(312,230," -");
outtextxy(405,230," -");
outtextxy(455,230," -");
outtextxy(525,230," -");
outtextxy(5,250,"RAJDHANI");
outtextxy(92,250, " 70");
outtextxy(144,250," 63");
outtextxy(194,250," 69");
outtextxy(260,250," -");
outtextxy(312,250," 75");
outtextxy(405,250," -");
outtextxy(455,250," -");
outtextxy(525,250," -");
outtextxy(5,270,"RAMJAS");
outtextxy(92,270, " 76");
outtextxy(144,270," 72");
outtextxy(194,270," 72");
outtextxy(260,270," -");
outtextxy(312,270," -");
outtextxy(405,270," 70");
outtextxy(455,270," -");
outtextxy(525,270," -");
outtextxy(5,290,"MAITREYI");
outtextxy(92,290, " 74");
outtextxy(144,290," 68");
outtextxy(194,290," 72");
outtextxy(260,290," 67");
outtextxy(312,290," -");
outtextxy(405,290," -");
outtextxy(455,290," 67");
outtextxy(525,290," -");
outtextxy(5,310,"ARSD");
outtextxy(92,310, " 73");
outtextxy(144,310," 67");
outtextxy(194,310," 68");
outtextxy(260,310," 79");
outtextxy(312,310," -");
outtextxy(405,310," -");
outtextxy(455,310," -");
outtextxy(525,310," -");
outtextxy(5,330,"SHIVAJI");
outtextxy(92,330, " 71");
outtextxy(144,330," 68");
outtextxy(194,330," 70");
outtextxy(260,330," 67");
outtextxy(312,330," -");
outtextxy(405,330," -");
outtextxy(455,330," 65");
outtextxy(525,330," 75");
outtextxy(5,350,"KHALSA");
outtextxy(92,350, " 78");
outtextxy(144,350," 78");
outtextxy(194,350," 75");
outtextxy(260,350," 67");
outtextxy(312,350," 85");
outtextxy(405,350," -");
outtextxy(455,350," 67");
outtextxy(525,350," -");
settextstyle(1,0,1);
rectangle(1,460,600,400);
outtextxy(10,410,"PRESS ANY KEY TO CONTINUE TO KNOW ABOUT :");
outtextxy(290,425,"B.SC - GENERAL COURSES");
char ch;
ch=getch();
cleardevice();
line(1,70,750,70);
line(1,90,750,90);
line(1,110,750,110);
line(1,130,750,130);
line(1,150,750,150);
line(1,170,750,170);
line(1,190,750,190);
line(1,210,750,210);
line(1,230,750,230);
line(1,250,750,250);
line(1,270,750,270);
line(1,290,750,290);
line(1,310,750,310);
line(1,330,750,330);
line(1,350,750,350);
line(1,370,750,370);
line(1,70,1,370);
line(100,90,100,370);
line(190,90,190,370);
line(280,90,280,370);
line(370,90,370,370);
line(460,90,460,370);
line(555,90,555,370);
line(639,70,639,370);
delay(1000);
settextstyle(1,0,1);
outtextxy(200,70," B.SC (GENERAL) COURSES");
delay(1000);
outtextxy(5,90,"COLLEGES");
outtextxy(102,90,"Gr.B(PCB)");
outtextxy(192,90,"Gr.A(PCM)");
outtextxy(282,90,"ELEC");
outtextxy(372,90,"IND.CHEM");
outtextxy(462,90,"COMPUTER");
outtextxy(555,90,"AGRO Ch");
outtextxy(5,110,"HANSRAJ");
outtextxy(105,110,"  71");
outtextxy(195,110,"  86.6");
outtextxy(285,110,"  -");
outtextxy(375,110,"  -");
outtextxy(465,110,"  86.67");
outtextxy(555,110,"  -");
outtextxy(5,130,"HINDU");
outtextxy(105,130,"  -");
outtextxy(195,130,"  80");
outtextxy(285,130,"  80");
outtextxy(375,130,"  -");
outtextxy(465,130,"  -");
outtextxy(555,130,"  -");
outtextxy(5,150,"PGDAV");
outtextxy(105,150,"  -");
outtextxy(195,150,"  -");
outtextxy(285,150,"  -");
outtextxy(375,150,"  -");
outtextxy(465,150,"  -");
outtextxy(555,150,"  -");
outtextxy(5,170,"AGARSAIN");
outtextxy(105,170,"  -");
outtextxy(195,170,"  -");
outtextxy(285,170,"  -");
outtextxy(375,170,"  -");
outtextxy(465,170,"  70");
outtextxy(555,170,"  -");
outtextxy(5,190,"SHYAMLAL");
outtextxy(105,190,"  55");
outtextxy(195,190,"  -");
outtextxy(285,190,"  -");
outtextxy(375,190,"  -");
outtextxy(465,190,"  -");
outtextxy(555,190,"  -");
outtextxy(5,210,"KALINDI");
outtextxy(105,210,"  59");
outtextxy(195,210,"  69");
outtextxy(285,210,"  -");
outtextxy(375,210,"  -");
outtextxy(465,210,"  -");
outtextxy(555,210,"  -");
outtextxy(5,230,"STEPHENS");
outtextxy(105,230,"  -");
outtextxy(195,230,"  -");
outtextxy(285,230,"  -");
outtextxy(375,230,"  -");
outtextxy(465,230,"  -");
outtextxy(555,230,"  -");
outtextxy(5,250,"RAJDHANI");
outtextxy(105,250,"  ");
outtextxy(195,250,"  60");
outtextxy(285,250,"  58");
outtextxy(375,250,"  56");
outtextxy(465,250,"  68");
outtextxy(555,250,"  -");
outtextxy(5,270,"RAMJAS");
outtextxy(105,270,"  67");
outtextxy(195,270,"  70");
outtextxy(285,270,"  72");
outtextxy(375,270,"  -");
outtextxy(465,270,"  -");
outtextxy(555,270,"  -");
outtextxy(5,290,"MAITREYI");
outtextxy(105,290,"  65");
outtextxy(195,290,"  65");
outtextxy(285,290,"  -");
outtextxy(375,290,"  -");
outtextxy(465,290,"  -");
outtextxy(555,290,"  -");
outtextxy(5,310,"ARSD");
outtextxy(105,310,"  65");
outtextxy(195,310,"  68");
outtextxy(285,310,"  -");
outtextxy(375,310,"  68");
outtextxy(465,310,"  -");
outtextxy(555,310,"  -");
outtextxy(5,330,"SHIVAJI");
outtextxy(105,330,"  64");
outtextxy(195,330,"  62");
outtextxy(285,330,"  70");
outtextxy(375,330,"  -");
outtextxy(465,330,"  79");
outtextxy(555,330,"  -");
outtextxy(5,350,"KHALSA");
outtextxy(105,350,"  68");
outtextxy(195,350,"  -");
outtextxy(285,350,"  -");
outtextxy(375,350,"  -");
outtextxy(465,350,"  81");
outtextxy(555,350,"  -");
settextstyle(1,0,1);
rectangle(1,460,600,400);
outtextxy(10,425,"PRESS ANY KEY TO RETURN TO MAIN MENU :");
ch=getch();
{
cleardevice();
closegraph();
menu();
sound(500);
delay(100);
nosound();
}
}

/****************************************************************************/
//CLASS NAME: career//
//FUNCTION NAME: commerce()//
//DETAILS: It displays the information about commerce stream when user press 2 //
/****************************************************************************/

void career::commerce()
{
int graphdriver = DETECT,graphmode,errorcode;
int midx,midy;
int xmax,ymax;
initgraph(&graphdriver, &graphmode,"..\\bgi");
setcolor(getmaxcolor());
xmax = getmaxx();
ymax = getmaxy();
settextstyle(1,0,3);
outtextxy(25,90,"THE SCREEN APPEARING NEXT WILL SHOW YOU THE  ");
delay(150);
outtextxy(25,115,"CUT OFF LIST OF VARIOUS COLLEGES PROVIDING ");
delay(150);
outtextxy(25,144,"EDUCATION IN THE FIELD OF COMMERCE.    ");
delay(3500);
cleardevice();
line(1,20,600,20);
line(1,40,600,40);
line(1,60,600,60);
line(1,80,600,80);
line(1,100,600,100);
line(1,120,600,120);
line(1,140,600,140);
line(1,160,600,160);
line(1,180,600,180);
line(1,200,600,200);
line(1,220,600,220);
line(1,240,600,240);
line(1,260,600,260);
line(1,280,600,280);
line(1,300,600,300);
line(1,320,600,320);
line(1,340,600,340);
line(1,360,600,360);
line(1,380,600,380);
line(1,400,600,400);
line(1,425,600,425);
line(1,20,1,425);
line(150,40,150,425);
line(230,40,230,425);
line(310,40,310,425);
line(390,40,390,425);
line(470,40,470,425);
line(600,20,600,425);
delay(1000);
settextstyle(1,0,1);
outtextxy(230,17," COMMERCE");
delay(1000);
outtextxy(5,37,"COLLEGES");
outtextxy(155,37,"B.A (P)");
outtextxy(235,37,"B.COM(P)");
outtextxy(315,37,"B.COM(H)");
outtextxy(395,37,"ECO.(H)");
outtextxy(475,37,"MATHS(H)");
settextstyle(1,0,1);
outtextxy(5,57,"A.R.S.D");
outtextxy(155,57," 58-70");
outtextxy(235,57," 74-81");
outtextxy(315,57," 77-84");
outtextxy(395,57,"   72");
outtextxy(475,57,"   65");
settextstyle(1,0,1);
outtextxy(5,77,"Bhim Rao");
outtextxy(155,77,"   68");
outtextxy(235,77,"   67");
outtextxy(315,77,"   66");
outtextxy(395,77,"   -");
outtextxy(475,77,"   -");
settextstyle(1,0,1);
outtextxy(5,97,"Daulat Ram");
outtextxy(155,97,"   -");
outtextxy(235,97,"   -");
outtextxy(315,97,"   -");
outtextxy(395,97,"   -");
outtextxy(475,97,"   -");
settextstyle(1,0,1);
outtextxy(5,117,"DeshBandhu");
outtextxy(155,117,"   61");
outtextxy(235,117,"   -");
outtextxy(315,117,"   75");
outtextxy(395,117,"   66");
outtextxy(475,117,"   60");
settextstyle(1,0,1);
outtextxy(5,137,"Dyal Singh");
outtextxy(155,137,"   63");
outtextxy(235,137,"   73");
outtextxy(315,137,"   77");
outtextxy(395,137,"   68");
outtextxy(475,137,"   58");
settextstyle(1,0,1);
outtextxy(5,157,"Gargi");
outtextxy(155,157,"   -");
outtextxy(235,157,"   -");
outtextxy(315,157,"   -");
outtextxy(395,157,"   -");
outtextxy(475,157,"   -");
settextstyle(1,0,1);
outtextxy(5,177,"Hansraj");
outtextxy(155,177,"   75");
outtextxy(235,177,"   -");
outtextxy(315,177,"   88");
outtextxy(395,177,"   86");
outtextxy(475,177,"   -");
settextstyle(1,0,1);
outtextxy(5,197,"Hindu");
outtextxy(155,197,"   72");
outtextxy(235,197,"   -");
outtextxy(315,197,"  86.5");
outtextxy(395,197,"  87.5");
outtextxy(475,197,"   82");
settextstyle(1,0,1);
outtextxy(5,217,"Jesus & Mary");
outtextxy(155,217,"   75");
outtextxy(235,217,"   84");
outtextxy(315,217,"   85");
outtextxy(395,217,"   82");
outtextxy(475,217,"   78");
settextstyle(1,0,1);
outtextxy(5,237,"Kirori Mal");
outtextxy(155,237,"   75");
outtextxy(235,237,"   84");
outtextxy(315,237,"  86.5");
outtextxy(395,237,"   80");
outtextxy(475,237,"   74");
settextstyle(1,0,1);
outtextxy(5,257,"Lakshmi Bai");
outtextxy(155,257,"   65");
outtextxy(235,257,"   73");
outtextxy(315,257,"   78");
outtextxy(395,257,"   -");
outtextxy(475,257,"   65");
settextstyle(1,0,1);
outtextxy(5,277,"Mata Sundari");
outtextxy(155,277,"   60");
outtextxy(235,277,"   -");
outtextxy(315,277,"   -");
outtextxy(395,277,"   -");
outtextxy(475,277,"   56");
settextstyle(1,0,1);
outtextxy(5,297,"Miranda House");
outtextxy(155,297,"   71");
outtextxy(235,297,"   -");
outtextxy(315,297,"   -");
outtextxy(395,297,"   -");
outtextxy(475,297,"   -");
settextstyle(1,0,1);
outtextxy(5,317,"P.G.D.A.V");
outtextxy(155,317,"   62");
outtextxy(235,317,"   73");
outtextxy(315,317,"   77");
outtextxy(395,317,"   68");
outtextxy(475,317,"   65");
settextstyle(1,0,1);
outtextxy(5,337,"Rajdhani");
outtextxy(155,337,"   60");
outtextxy(235,337,"   -");
outtextxy(315,337,"   78");
outtextxy(395,337,"   67");
outtextxy(475,337,"  65-78");
settextstyle(1,0,1);
outtextxy(5,357,"Ramjas");
outtextxy(155,357,"   70");
outtextxy(235,357,"   -");
outtextxy(315,357,"   -");
outtextxy(395,357,"   -");
outtextxy(475,357,"   -");
settextstyle(1,0,1);
outtextxy(5,377,"Khalsa");
outtextxy(155,377,"   66");
outtextxy(235,377,"  82.5");
outtextxy(315,377,"   82.75");
outtextxy(395,377,"   78");
outtextxy(475,377,"   -");
settextstyle(1,0,1);
outtextxy(5,397,"Satyawati");
outtextxy(155,397,"   56");
outtextxy(235,397,"  75.5");
outtextxy(315,397,"  77.5");
outtextxy(395,397,"  66.75");
outtextxy(475,397,"   63");
settextstyle(1,0,1);
outtextxy(10,430,"PRESS ANY KEY TO RETURN TO MAIN MENU :");
int ch;
ch=getch();
{
cleardevice();
closegraph();
menu();
}
}

/****************************************************************************/
//CLASS NAME: career//
//FUNCTION NAME: arts()//
//DETAILS: It displays the information about arts stream when user press 3 //
/****************************************************************************/

void career::arts()
{
int graphdriver = DETECT,graphmode,errorcode;
int midx,midy;
int xmax,ymax;
initgraph(&graphdriver, &graphmode,"..\\bgi");
setcolor(getmaxcolor());
xmax = getmaxx();
ymax = getmaxy();
settextstyle(1,0,3);
outtextxy(25,90,"THE SCREEN APPEARING NEXT WILL SHOW YOU THE  ");
delay(150);
outtextxy(25,115,"CUT OFF LIST OF VARIOUS COLLEGES PROVIDING ");
delay(150);
outtextxy(25,144,"EDUCATION IN THE FIELD OF HUMANITIES.   ");
delay(3000);
cleardevice();
line(1,20,600,20);
line(1,40,600,40);
line(1,60,600,60);
line(1,80,600,80);
line(1,100,600,100);
line(1,120,600,120);
line(1,140,600,140);
line(1,160,600,160);
line(1,180,600,180);
line(1,200,600,200);
line(1,220,600,220);
line(1,240,600,240);
line(1,260,600,260);
line(1,280,600,280);
line(1,300,600,300);
line(1,320,600,320);
line(1,340,600,340);
line(1,360,600,360);
line(1,380,600,380);
line(1,400,600,400);
line(1,425,600,425);
line(1,20,1,425);
line(150,40,150,425);
line(230,40,230,425);
line(310,40,310,425);
line(390,40,390,425);
line(470,40,470,425);
line(600,20,600,425);
delay(1000);
settextstyle(1,0,1);
outtextxy(230,17," ARTS (HUMANITIES) ");
delay(1000);
outtextxy(5,37,"COLLEGES");
outtextxy(155,37," HIST.");
outtextxy(235,37," POL.SC.");
outtextxy(315,37," SOCIO.");
outtextxy(395,37," GEO.");
outtextxy(475,37," PSY.");
settextstyle(1,0,1);
outtextxy(5,57,"A.R.S.D");
outtextxy(155,57,"  60-70");
outtextxy(235,57,"    -");
outtextxy(315,57,"    -");
outtextxy(395,57,"    -");
outtextxy(475,57,"    -");
settextstyle(1,0,1);
outtextxy(5,77,"Bhim Rao");
outtextxy(155,77,"   -");
outtextxy(235,77,"   -");
outtextxy(315,77,"   -");
outtextxy(395,77,"   58");
outtextxy(475,77,"   -");
settextstyle(1,0,1);
outtextxy(5,97,"Daulat Ram");
outtextxy(155,97,"   -");
outtextxy(235,97," 68-73");
outtextxy(315,97,"   -");
outtextxy(395,97,"   -");
outtextxy(475,97,"  75.5");
settextstyle(1,0,1);
outtextxy(5,117,"DeshBandhu");
outtextxy(155,117,"   55");
outtextxy(235,117,"   -");
outtextxy(315,117,"   58");
outtextxy(395,117,"   -");
outtextxy(475,117,"   -");
settextstyle(1,0,1);
outtextxy(5,137,"Dyal Singh");
outtextxy(155,137," 55-62");
outtextxy(235,137," 60-55");
outtextxy(315,137,"   -");
outtextxy(395,137," 61-72");
outtextxy(475,137,"   -");
settextstyle(1,0,1);
outtextxy(5,157,"Gargi");
outtextxy(155,157,"   62");
outtextxy(235,157,"   -");
outtextxy(315,157,"   -");
outtextxy(395,157,"   -");
outtextxy(475,157,"   -");
settextstyle(1,0,1);
outtextxy(5,177,"Hansraj");
outtextxy(155,177," 72-75");
outtextxy(235,177,"   -");
outtextxy(315,177,"   -");
outtextxy(395,177,"   -");
outtextxy(475,177,"   -");
settextstyle(1,0,1);
outtextxy(5,197,"Hindu");
outtextxy(155,197,"  73.5");
outtextxy(235,197,"  73.5");
outtextxy(315,197," 74-81");
outtextxy(395,197,"   -");
outtextxy(475,197,"   -");
settextstyle(1,0,1);
outtextxy(5,217,"Jesus & Mary");
outtextxy(155,217,"   70");
outtextxy(235,217,"   77");
outtextxy(315,217,"   80");
outtextxy(395,217,"   -");
outtextxy(475,217,"   83");
settextstyle(1,0,1);
outtextxy(5,237,"Kirori Mal");
outtextxy(155,237," 69-74");
outtextxy(235,237," 72-78");
outtextxy(315,237,"   -");
outtextxy(395,237," 70-75");
outtextxy(475,237,"   -");
settextstyle(1,0,1);
outtextxy(5,257,"Lakshmi Bai");
outtextxy(155,257,"   55");
outtextxy(235,257,"   60");
outtextxy(315,257,"   -");
outtextxy(395,257,"   -");
outtextxy(475,257,"   -");
settextstyle(1,0,1);
outtextxy(5,277,"Mata Sundari");
outtextxy(155,277,"   50");
outtextxy(235,277,"   58");
outtextxy(315,277,"   -");
outtextxy(395,277,"   60");
outtextxy(475,277,"   -");
settextstyle(1,0,1);
outtextxy(5,297,"Miranda House");
outtextxy(155,297,"   -");
outtextxy(235,297,"   -");
outtextxy(315,297,"   -");
outtextxy(395,297,"   -");
outtextxy(475,297,"   -");
settextstyle(1,0,1);
outtextxy(5,317,"P.G.D.A.V");
outtextxy(155,317," 50-57");
outtextxy(235,317," 50-57");
outtextxy(315,317,"   -");
outtextxy(395,317,"   -");
outtextxy(475,317,"   -");
settextstyle(1,0,1);
outtextxy(5,337,"Rajdhani");
outtextxy(155,337," 59-62");
outtextxy(235,337,"   60");
outtextxy(315,337,"   -");
outtextxy(395,337,"   -");
outtextxy(475,337,"   -");
settextstyle(1,0,1);
outtextxy(5,357,"Ramjas");
outtextxy(155,357," 62-75");
outtextxy(235,357," 70-75");
outtextxy(315,357,"   -");
outtextxy(395,357,"   -");
outtextxy(475,357,"   -");
settextstyle(1,0,1);
outtextxy(5,377,"Khalsa");
outtextxy(155,377,"   63");
outtextxy(235,377,"   66");
outtextxy(315,377,"   -");
outtextxy(395,377,"   -");
outtextxy(475,377,"   -");
settextstyle(1,0,1);
outtextxy(5,397,"Satyawati");
outtextxy(155,397,"   57");
outtextxy(235,397,"   57");
outtextxy(315,397,"   -");
outtextxy(395,397,"   -");
outtextxy(475,397,"   -");
settextstyle(1,0,1);
int ch;
outtextxy(10,430,"PRESS ANY KEY TO RETURN TO MAIN MENU :");
ch=getch();
{
cleardevice();
closegraph();
menu();
}
}

/****************************************************************************/
//CLASS NAME: career//
//FUNCTION NAME: colleges()//
//DETAILS: It displays the name of the colleges region wise //
/****************************************************************************/

void career::colleges()
{
char ch;
int midx,midy,size,style;
char CENTRE_TEXT;
int graphdriver = DETECT,graphmode,errorcode;
initgraph(&graphdriver, &graphmode, "..//bgi");
cleardevice();
settextstyle(1,0,3);
setcolor(LIGHTBLUE);
delay(350);
cleardevice();
settextstyle(1,0,3);
outtextxy(10,250, "U");
delay(400);
outtextxy(40,250, "N");
delay(400);
outtextxy(70,250, "I");
delay(400);
outtextxy(100,250,"V");
delay(400);
outtextxy(130,250,"E");
delay(400);
outtextxy(160,250,"R");
delay(400);
outtextxy(190,250,"S");
delay(400);
outtextxy(220,250,"I");
delay(400);
outtextxy(250,250,"T");
delay(400);
outtextxy(280,250,"Y");
delay(400);
outtextxy(350,250,"O");
delay(400);
outtextxy(380,250,"F");
delay(400);
outtextxy(440,250,"D");
delay(400);
outtextxy(470,250,"E");
delay(400);
outtextxy(500,250,"L");
delay(400);
outtextxy(530,250,"H");
delay(400);
outtextxy(560,250,"I");
{
sound(500);
delay(100);
nosound();
}
delay(700);
cleardevice();
settextstyle(1,0,3);
setcolor(3);
delay(350);
outtextxy(10,20,"********************************************************************");
delay(350);
outtextxy(180,50,"*** COLLEGES IN FOCUS ***");
delay(350);
outtextxy(10,80,"********************************************************************");
delay(400);
outtextxy(10,110,"- Bhimrao Ambedkar College");
delay(400);
outtextxy(10,140,"- College of Applied Science for Women");
delay(400);
outtextxy(10,170,"- College of Art");
delay(400);
outtextxy(10,200,"- College of Business Studies");
delay(400);
outtextxy(10,230,"- Delhi School of Economics");
delay(400);
outtextxy(10,260,"- Deshbandu College");
delay(400);
outtextxy(10,290,"- Hansraj College");
delay(400);
outtextxy(10,320,"- Kirorimal College");
delay(400);
outtextxy(10,350,"- Lady Irwin College");
delay(400);
setcolor(12+128);
settextstyle(1,0,1);
rectangle(1,460,630,400);
outtextxy(10,410,"PRESS ANY KEY TO CONTINUE");
outtextxy(10,425,"PRESS <Esc> TO RETURN TO MAIN MENU");
ch=getch();
char st[100];
st[0]=ch;
st[1]='\0';
outtextxy(10,650,st);
if(ch==27)
{
cleardevice();
closegraph();
menu();
sound(500);
delay(100);
nosound();
}
cleardevice();
setcolor(3);
delay(400);
outtextxy(10,20,"- Miranda House");
delay(400);
outtextxy(10,50,"- Sri Vankateshwara College");
delay(400);
outtextxy(10,80 ,"- Maharaja Agrasen College");
delay(400);
outtextxy(10,110,"- Laxmi Bai College [W]");
delay(400);
setcolor(12+128);
settextstyle(1,0,1);
rectangle(1,460,630,400);
outtextxy(10,410,"PRESS ANY KEY TO CONTINUE");
outtextxy(10,425,"PRESS <Esc> TO RETURN TO MAIN MENU");
ch=getch();
st[0]=ch;
st[1]='\0';
outtextxy(10,650,st);
if(ch==27)
{
cleardevice();
closegraph();
menu();
sound(500);
delay(100);
nosound();
}
cleardevice();
setcolor(3);
delay(400);
outtextxy(50,20,"********************************************************************");
delay(350);
outtextxy(180,50,"*** NORTH DELHI ***");
delay(350);
outtextxy(50,80,"********************************************************************");
delay(400);
outtextxy(10,110,"- Aditi Mahavidyalaya");
delay(400);
outtextxy(10,140,"- Daulat Ram College");
delay(400);
outtextxy(10,170,"- Indraprastha College [W]");
delay(400);
outtextxy(10,200,"- Hindu College");
delay(400);
outtextxy(10,230,"- Ramjas College");
delay(400);
outtextxy(10,260,"- Sri Guru Teg Bahadur Khalsa College");
delay(400);
outtextxy(10,290,"- Sri Guru Teg Bahadur Khalsa College (EVE)");
delay(400);
outtextxy(10,320,"- Satyawati College");
delay(400);
setcolor(12+128);
settextstyle(1,0,1);
rectangle(1,460,630,400);
outtextxy(10,410,"PRESS ANY KEY TO CONTINUE");
outtextxy(10,425,"PRESS <Esc> TO RETURN TO MAIN MENU");
ch=getch();
st[0]=ch;
st[1]='\0';
outtextxy(10,650,st);
if(ch==27)
{
cleardevice();
closegraph();
menu();
sound(500);
delay(100);
nosound();
}
cleardevice();
setcolor(3);
delay(400);
outtextxy(10,20,"- School of Correspondance Cources & Continuing ");
outtextxy(10,45,"  Education");
delay(400);
outtextxy(10,80,"- Sri Ram College of Commerce");
delay(400);
outtextxy(10,110,"- Sri Guru Govind Singh College of Commerce");
delay(400);
outtextxy(10,140,"- St. Stephen's College");
delay(400);
outtextxy(10,170,"- Swami Shardhanand College");
delay(400);
setcolor(12+128);
settextstyle(1,0,1);
rectangle(1,460,630,400);
outtextxy(10,410,"PRESS ANY KEY TO CONTINUE");
outtextxy(10,425,"PRESS <Esc> TO RETURN TO MAIN MENU");
ch=getch();
st[0]=ch;
st[1]='\0';
outtextxy(10,650,st);
if(ch==27)
{
cleardevice();
closegraph();
menu();
sound(500);
delay(100);
nosound();
}
cleardevice();
setcolor(3);
delay(400);
outtextxy(50,20,"********************************************************************");
delay(350);
outtextxy(180,50,"*** EAST DELHI ***");
delay(350);
outtextxy(50,80,"********************************************************************");
delay(400);
outtextxy(10,110,"- Shyam Lal College");
delay(400);
outtextxy(10,140,"- Vivekanand Mahila College");
delay(400);
outtextxy(10,170,"- Maharishi Valmiki College of Eduction");
delay(400);
setcolor(12+128);
settextstyle(1,0,1);
rectangle(1,460,630,400);
outtextxy(10,410,"PRESS ANY KEY TO CONTINUE");
outtextxy(10,425,"PRESS <Esc> TO RETURN TO MAIN MENU");
ch=getch();
st[0]=ch;
st[1]='\0';
outtextxy(10,650,st);
if(ch==27)
{
cleardevice();
closegraph();
menu();
sound(500);
delay(100);
nosound();
}
cleardevice();
setcolor(3);
delay(400);
outtextxy(50,20,"********************************************************************");
delay(350);
outtextxy(180,50,"*** CENTRAL DELHI ***");
delay(350);
outtextxy(50,80,"********************************************************************");
delay(400);
outtextxy(10,110,"- Mata Sundari College [W]") ;
delay(400);
outtextxy(10,140,"- Zakir Hussain College") ;
delay(100);
setcolor(12+128);
settextstyle(1,0,1);
rectangle(1,460,630,400);
outtextxy(10,410,"PRESS ANY KEY TO CONTINUE");
outtextxy(10,425,"PRESS <Esc> TO RETURN TO MAIN MENU");
ch=getch();
st[0]=ch;
st[1]='\0';
outtextxy(10,650,st);
if(ch==27)
{
cleardevice();
closegraph();
menu();
sound(500);
delay(100);
nosound();
}
cleardevice();
setcolor(3);
delay(400);
outtextxy(50,20,"********************************************************************");
delay(350);
outtextxy(180,50,"*** WEST DELHI ***");
delay(350);
outtextxy(50,80,"********************************************************************");
delay(400);
outtextxy(10,110,"- Bhagini Nivedita College");
delay(400);
outtextxy(10,140,"- Bharti College [W]");
delay(400);
outtextxy(10,170,"- College of Pharmacy");
delay(400);
outtextxy(10,200,"- Deen Dayal Upadhyaya College");
delay(400);
outtextxy(10,230,"- Indira Gandhi College of Physical Education & ");
delay(400);
outtextxy(10,260,"  Sports Sciences");
delay(400);
outtextxy(10,290,"- Janki Devi Memorial College [W]");
delay(400);
outtextxy(10,320,"- Kalindi College");
delay(400);
outtextxy(10,350,"- Keshav College");
delay(400);
setcolor(12+128);
settextstyle(1,0,1);
rectangle(1,460,630,400);
outtextxy(10,410,"PRESS ANY KEY TO CONTINUE");
outtextxy(10,425,"PRESS <Esc> TO RETURN TO MAIN MENU");
ch=getch();
st[0]=ch;
st[1]='\0';
outtextxy(10,650,st);
if(ch==27)
{
cleardevice();
closegraph();
menu();
sound(500);
delay(100);
nosound();
}
cleardevice();
setcolor(3);
delay(400);
outtextxy(10,20,"- Deshbandhu College");
delay(400);
outtextxy(10,50,"- Netaji Subhas Institute of Technology");
delay(400);
outtextxy(10,80,"- Rajdhani College");
delay(400);
outtextxy(10,110,"- Shivaji College");
delay(400);
outtextxy(10,140,"- Shyama Prasad Mukherjee College [W]");
delay(400);
setcolor(12+128);
settextstyle(1,0,1);
rectangle(1,460,630,400);
outtextxy(10,410,"PRESS ANY KEY TO CONTINUE");
outtextxy(10,425,"PRESS <Esc> TO RETURN TO MAIN MENU");
ch=getch();
st[0]=ch;
st[1]='\0';
outtextxy(10,650,st);
if(ch==27)
{
cleardevice();
closegraph();
menu();
sound(500);
delay(100);
nosound();
}
cleardevice();
setcolor(3);
delay(400);
outtextxy(50,20,"********************************************************************");
delay(350);
outtextxy(180,50,"*** SOUTH DELHI ***");
delay(350);
outtextxy(50,80,"********************************************************************");
delay(400);
outtextxy(10,110,"- Acharya Narendra Dev College");
delay(400);
outtextxy(10,140,"- Atma Ram Sanatan Dharma College ");
delay(400);
outtextxy(10,170,"- College of Vocational College");
delay(400);
outtextxy(10,200,"- Dayal Singh College");
delay(400);
outtextxy(10,230,"- Delhi College of Arts And Commerce");
delay(400);
outtextxy(10,260,"- Gargi College");
delay(400);
outtextxy(10,290,"- Institute of Home Economics");
delay(400);
outtextxy(10,320,"- Jesus & Marry College");
delay(400);
outtextxy(10,350,"- Kamla Nehru College For Women");
delay(400);
setcolor(12);
settextstyle(1,0,1);
rectangle(1,460,630,400);
outtextxy(10,410,"PRESS ANY KEY TO CONTINUE");
outtextxy(10,425,"PRESS <Esc> TO RETURN TO MAIN MENU");
ch=getch();
st[0]=ch;
st[1]='\0';
outtextxy(10,650,st);
if(ch==27)
{
cleardevice();
closegraph();
menu();
}
cleardevice();
setcolor(3);
delay(400);
outtextxy(10,20,"- Lady Shri Ram College For Women");
delay(400);
outtextxy(10,50,"- Moti Lal Nehru College");
delay(400);
outtextxy(10,80,"- Maitreyi College");
delay(400);
outtextxy(10,110,"- PGDAV College ");
delay(400);
outtextxy(10,140,"- Ram Lal Anand College ");
delay(400);
outtextxy(10,170,"- Shaheed Bhagat Singh College ");
delay(400);
outtextxy(10,200,"- Sri Aurobindo College ");
delay(400);
setcolor(12);
settextstyle(1,0,1);
rectangle(1,460,630,400);
outtextxy(10,410,"PRESS ANY KEY TO CONTINUE");
outtextxy(10,425,"PRESS <Esc> TO RETURN TO MAIN MENU");
ch=getch();
st[0]=ch;
st[1]='\0';
outtextxy(10,650,st);
if(ch==27)
{
cleardevice();
closegraph();
menu();
sound(500);
delay(100);
nosound();
}
cleardevice();
setcolor(3);
delay(400);
outtextxy(50,20,"********************************************************************");
delay(350);
outtextxy(180,50,"*** PRIVATE INSTITUTIONS ***");
delay(350);
outtextxy(50,80,"********************************************************************");
delay(400);
outtextxy(10,110,"- TVB School of Habit Studies");
delay(400);
outtextxy(10,140,"- Vaastu Kala Academy");
delay(400);
outtextxy(10,170,"- Amity School of Engineering & Technology");
delay(400);
outtextxy(10,200,"- Sushant Lok School of Art & Architecture");
setcolor(12);
settextstyle(1,0,1);
rectangle(1,460,630,400);
outtextxy(10,410,"PRESS ANY KEY TO CONTINUE");
outtextxy(10,425,"PRESS <Esc> TO RETURN TO MAIN MENU");
ch=getch();
st[0]=ch;
st[1]='\0';
outtextxy(10,650,st);
if(ch==27)
{
cleardevice();
closegraph();
menu();
sound(500);
delay(100);
nosound();
}
cleardevice();
setcolor(3);
delay(400);
outtextxy(40,20,"********************************************************************");
delay(350);
outtextxy(55,50,"*** POST GRADUATE COURSES AT SOUTH CAMPUS ***");
delay(350);
outtextxy(40,80,"********************************************************************");
delay(400);
outtextxy(10,110,"- Institute of Informatics And Communications") ;
delay(400);
outtextxy(10,140,"- Department of Financial Studies") ;
delay(400);
setcolor(12);
settextstyle(1,0,1);
settextstyle(1,0,1);
rectangle(1,460,630,400);
outtextxy(10,410,"PRESS ANY KEY TO CONTINUE");
outtextxy(10,425,"PRESS <Esc> TO RETURN TO MAIN MENU");
ch=getch();
st[0]=ch;
st[1]='\0';
outtextxy(10,650,st);
if(ch==27)
{
cleardevice();
closegraph();
menu();
sound(500);
delay(100);
nosound();
}
cleardevice();
setcolor(3);
delay(400);
outtextxy(40,20,"********************************************************************");
delay(350);
outtextxy(55,50,"*** MANAGEMENT AND FINANCE EDUCATION ***");
delay(350);
outtextxy(40,80,"********************************************************************");
delay(400);
outtextxy(10,110,"- Indian Institute of Foreign Trade");
delay(400);
outtextxy(10,140,"- Indian Institute of Technology ");
delay(400);
outtextxy(10,170,"- Times School of Marketing");
delay(400);
outtextxy(10,200,"- Institute of Management Technology");
delay(400);
outtextxy(10,230,"- Foundation of Organisational Research And Education School" );
delay(400);
outtextxy(10,260,"  of Management");
delay(400);
outtextxy(10,290,"- Amity Business School");
delay(400);
outtextxy(10,320,"- Indian Institution of Planning And Management");
delay(400);
outtextxy(10,350,"- Institute of Productivity And Management");
delay(400);
setcolor(12);
settextstyle(1,0,1);
settextstyle(1,0,1);
rectangle(1,460,630,400);
outtextxy(10,410,"PRESS ANY KEY TO CONTINUE");
outtextxy(10,425,"PRESS <Esc> TO RETURN TO MAIN MENU");
ch=getch();
st[0]=ch;
st[1]='\0';
outtextxy(10,650,st);
if(ch==27)
{
cleardevice();
closegraph();
menu();
sound(500);
delay(100);
nosound();
}
cleardevice();
setcolor(3);
delay(400);
outtextxy(10,20,"- Management Development Institute ");
delay(400);
outtextxy(10,50,"- Northern Institute For Integrated Learning In");
delay(400);
outtextxy(10,80,"  Management ");
delay(400);
outtextxy(10,110,"- Skyline Business School");
delay(400);
outtextxy(10,140,"- Jagannath International Management School");
delay(400);
outtextxy(10,170,"- Institute of Management Studies");
delay(400);
outtextxy(10,200,"- Shiva Institute of Management Studies");
delay(400);
outtextxy(10,230,"- Centre For International Management");
delay(400);
outtextxy(10,260,"- Delhi School of Business");
delay(400);
outtextxy(10,290,"- Institute of Charted Accountants of India");
delay(400);
outtextxy(10,320,"- Institute of Company Secretaries of India");
delay(400);
outtextxy(10,350,"- Institute of Cost And Works Accountants of India");
delay(400);
setcolor(12);
settextstyle(1,0,1);
settextstyle(1,0,1);
rectangle(1,460,630,400);
outtextxy(10,410,"PRESS ANY KEY TO CONTINUE");
outtextxy(10,425,"PRESS <Esc> TO RETURN TO MAIN MENU");
st[0]=ch;
st[1]='\0';
outtextxy(10,650,st);
if(ch==27)
{
cleardevice();
closegraph();
menu();
sound(500);
delay(100);
nosound();
}
}

/****************************************************************************/
//CLASS NAME: career//
//FUNCTION NAME: profile()//
//DETAILS: It displays the name of various universities in delhi //
/****************************************************************************/

void career::profile()
{
char ch;
int graphdriver = DETECT,graphmode,errorcode;
initgraph(&graphdriver, &graphmode, "..//bgi");
cleardevice();
settextstyle(1,0,3);
outtextxy(10,250, "U");
delay(400);
outtextxy(40,250, "N");
delay(400);
outtextxy(70,250, "I");
delay(400);
outtextxy(100,250,"V");
delay(400);
outtextxy(130,250,"E");
delay(400);
outtextxy(160,250,"R");
delay(400);
outtextxy(190,250,"S");
delay(400);
outtextxy(220,250,"I");
delay(400);
outtextxy(250,250,"T");
delay(400);
outtextxy(280,250,"Y");
delay(400);
outtextxy(350,250,"O");
delay(400);
outtextxy(380,250,"F");
delay(400);
outtextxy(440,250,"D");
delay(400);
outtextxy(470,250,"E");
delay(400);
outtextxy(500,250,"L");
delay(400);
outtextxy(530,250,"H");
delay(400);
outtextxy(560,250,"I");
{
sound(500);
delay(100);
nosound();
}
delay(700);
cleardevice();
settextstyle(1,0,3);
setcolor(LIGHTBLUE);
delay(350);
outtextxy(10,20,"********************************************************************");
delay(350);
outtextxy(180,50,"*** UNIVERSITIES IN DELHI ***");
delay(350);
outtextxy(10,80,"********************************************************************");
delay(400);
outtextxy(10,110,"1: GURU GOBIND SINGH INDRAPRASTHA UNIVERSITY");
delay(400);
outtextxy(10,140,"2: JAWAHARLAL NEHRU UNIVERSITY");
delay(400);
outtextxy(10,170,"3: JAMIA MILLIA ISLAMIA");
delay(400);
outtextxy(10,200,"4: INDIRA GANDHI NATIONAL OPEN UNIVERSITY");
delay(400);
outtextxy(10,230,"5: INDIAN AGRICULTURAL RESEARCH INSTITUTE");
delay(400);
outtextxy(10,260,"6: JAMIA HAMDARD");
delay(400);
outtextxy(10,290,"7: TERI SCHOOL OF ADVANCED STUDIES ");
delay(400);
outtextxy(10,320,"8: SRI LAL BAHADUR SHASTRI RASHTRIYA SANSKRIT VIDHAPEETH ");
delay(400);
outtextxy(10,350,"9: TECHNICAL EDUCATION");
delay(400);
setcolor(12+128);
settextstyle(1,0,1);
rectangle(1,460,630,400);
outtextxy(10,410,"PRESS ANY KEY TO RETURN TO MAIN MENU");
outtextxy(10,430,"ENTER YOUR CHOICE:");
ch=getch();
{
cleardevice();
closegraph();
menu();
sound(500);
delay(100);
nosound();
}
}

/****************************************************************************/
//CLASS NAME: career//
//FUNCTION NAME: acknow()//
//DETAILS: It displays accepts rows & columns &draw a horizontal line //
/****************************************************************************/

void career::acknow()
{
int midx,midy,size,style;
char CENTRE_TEXT;
int graphdriver = DETECT,graphmode,errorcode;
initgraph(&graphdriver, &graphmode, "..//bgi");
int  a=5,b=10,c=630,d=450;
for(int i=9;i<=13;i++)
{
setcolor(i);
rectangle(a,b,c,d);
a+=3;
b+=3;
c-=3;
d-=3;
delay(100);
sound(500);
delay(50);
nosound();
}
setcolor(CYAN);
settextstyle(1,0,6);
outtextxy(100,20,"ACKNOWLEDGEMENT");
settextstyle(1,0,3);
outtextxy(25,90,"It give me immense pleasure in expressing a ");
outtextxy(25,115,"deep sense of gratitude to my respected teacher ");
outtextxy(180,142,"Ms. NITI ARORA");
outtextxy(25,165,"and lab. assistant for their inspiring guidance");
outtextxy(25,188,"throughout the preparation of the project.");
outtextxy(60,212,"This project would not have taken the present");
outtextxy(25,232,"shape without the valuable guidance of them.");
outtextxy(25,266,"GDG");
outtextxy(25,288,"XII-B");
outtextxy(25,370,"< PRESS ANY KEY TO CONTINUE >");
getch();
end();
closegraph();
}

/****************************************************************************/
//CLASS NAME: career//
//FUNCTION NAME: ce()//
//DETAILS: It displays information about computer education //
/****************************************************************************/

void career::ce()
{
char ch;
int graphdriver = DETECT,graphmode,errorcode;
initgraph(&graphdriver, &graphmode, "..//bgi");
cleardevice();
settextstyle(1,0,3);
setcolor(LIGHTBLUE);
delay(350);
outtextxy(180,30,"COMPUTER-EDUCATION ");
delay(350);
sound(500);
delay(100);
nosound();
outtextxy(10,55,"1:  Indian Institute of Hardware Technology");
delay(350);
sound(500);
delay(100);
nosound();
outtextxy(10,85,"2:  Indian Institute of Computer Education");
delay(400);
sound(500);
delay(100);
nosound();
outtextxy(10,115,"3:  El Net-3L Academy");
delay(400);
sound(500);
delay(100);
nosound();
outtextxy(10,145,"4:  NIIT");
delay(400);
sound(500);
delay(100);
nosound();
outtextxy(10,175,"5:  CMC");
delay(400);
sound(500);
delay(100);
nosound();
outtextxy(10,205,"6:  Lakhotia Computer Centre");
delay(400);
sound(500);
setcolor(12+128);
settextstyle(1,0,1);
rectangle(1,460,630,400);
sound(500);
delay(100);
nosound();
outtextxy(10,400,"PRESS <Esc> TO RETURN TO MAIN MENU");
outtextxy(10,417,"PRESS ASSOCIATED No.TO KNOW MORE ABOUT GIVEN INSTIT.");
outtextxy(10,435,"ENTER YOUR CHOICE:");
ch=getch();
closegraph();
if(ch=='1')
{
clrscr();
textcolor(CYAN);
gotoxy(20,1);
cout<<"Indian Institute of Hardware Technology";
textcolor(YELLOW);
gotoxy(1,3);
cout<<"B-78,Sector VI,Noida-201301";
gotoxy(1,4);
cout<<"Tele: 91-4521118,91-4543089 Fax: 91-4550746";
gotoxy(1,5);
cout<<"E-mail: iihtnet@ndf.vsnl.net.in";
textcolor(CYAN);
gotoxy(1,7);
cout<<"INSTITUTIONAL PROFILE:";
textcolor(YELLOW);
gotoxy(1,8);
cout<<"IIHT is the India's oldest company in computer hardware,networking,tele-";
gotoxy(1,9);
cout<<"communication and robotics training organisation.IIHT introduced the concept ";
gotoxy(1,10);
cout<<"of computer hardware education in India in 1991.At present IIHT operates 50 ";
gotoxy(1,11);
cout<<"centres throughout India.IIHT offers courses in the entire spectrum of computer";
gotoxy(1,12);
cout<<"hardware,networking ,Internet,telecommunication and robotics under one roof and ";
gotoxy(1,13);
cout<<"has trained over 30,000 students.  ";
textcolor(CYAN);
gotoxy(1,15);
cout<<"INFRASTRUCTURAL FACILITIES:";
textcolor(YELLOW);
gotoxy(1,16);
cout<<"Research & Development wing of IIHT has designed the real expanded working ";
gotoxy(1,17);
cout<<"models of equipment. These trainers are infact 4-6 times expanded versions of ";
gotoxy(1,18);
cout<<"actual compact working equipment.IIHT offers JOB GUARANTEE IN WRITTING ON STAMP PAPER.";
textcolor(CYAN);
gotoxy(1,21);
cout<<"COURSES:";
textcolor(YELLOW);
gotoxy(1,22);
cout<<"-IIHT certified Networking Engineering(36 months)for 10+2 Science students. ";
textcolor(CYAN);
gotoxy(1,24);
cout<<"< PRESS ANY KEY TO CONTINUE >";
getch();
clrscr();
textcolor(YELLOW);
gotoxy(1,1);
cout<<"-IIHT certified Electronic Engineering(36 months)for 10+2 Science students.  ";
gotoxy(1,2);
cout<<"-IIHT certified Automation Engineering(36 months)for 10+2 Science students. ";
gotoxy(1,3);
cout<<"-Advance diploma in Computer & Telecommunication Engineering(24 months) for  ";
gotoxy(1,4);
cout<<" 10+2 students of any stream. ";
gotoxy(1,5);
cout<<"-Integrated Diploma in Computer Software,Hardware&Network Engineering(12 months)  ";
gotoxy(1,6);
cout<<" for 10+2 students of any stream.  ";
gotoxy(1,7);
cout<<"-Diploma in Telecommunication & Network Engineering (12 months)for 10+2 students ";
gotoxy(1,8);
cout<<" of any stream. ";
gotoxy(1,9);
cout<<"-Diploma in Computer Software,Hardware&Network Engineering(12 months) for 10+2   ";
gotoxy(1,10);
cout<<"-students of any stream. ";
textcolor(CYAN);
gotoxy(1,12);
cout<<"START UP COURSES: ";
textcolor(YELLOW);
gotoxy(1,13);
cout<<"Short term courses offered for specific purposes to different target audiences. ";
gotoxy(1,14);
cout<<"These courses are generally short term & are of informative nature. ";
textcolor(CYAN);
gotoxy(1,16);
cout<<"BOOSTER COURSES:  ";
textcolor(YELLOW);
gotoxy(1,17);
cout<<"These courses are specifically designed to equip students with the knowledge";
gotoxy(1,18);
cout<<"& skills that are necessary to succeed as a professional.A variety of courses";
gotoxy(1,19);
cout<<"of different spans are available.";
textcolor(CYAN);
gotoxy(1,21);
cout<<"STEP UP COURSES:";
textcolor(YELLOW);
gotoxy(1,22);
cout<<"These courses are offered for those with prior knowledge and/or experience in";
textcolor(CYAN);
gotoxy(1,24);
cout<<"< PRESS ANY KEY TO CONTINUE >";
getch();
clrscr();
textcolor(YELLOW);
gotoxy(1,1);
cout<<"the Information Technology area.";
gotoxy(1,3);
cout<<"FEES:";
gotoxy(1,4);
cout<<"For 12 months course : Rs 18,000 & for 18 months course: Rs 26,000";
gotoxy(1,5);
cout<<"For 24 months course : Rs 34,000 & for 36 months course: Rs 50,000";
gotoxy(1,7);
cout<<"IIHT centre in Delhi at A-166 ,Ashok Vihar Phase 1,(opp, D-block School)";
gotoxy(1,8);
cout<<"Delhi-110052";
textcolor(CYAN);
gotoxy(1,23);
cout<<"< PRESS ANY KEY TO RETURN TO COMPUTER EDUCATION MENU >";
getch();
{
clrscr();
ce();
sound(500);
delay(100);
nosound();
}
}
else
if(ch=='2')
{
clrscr();
textcolor(CYAN);
gotoxy(1,1);
cout<<"Indian Institute of Computer Education";
textcolor(YELLOW);
gotoxy(1,3);
cout<<"IICE House,C-574,Saraswati Vihar,Pitampura,Delhi-110034";
gotoxy(1,4);
cout<<"Telefax: 7018083,7021619,7017934 ";
gotoxy(1,5);
cout<<"E-mail: sdm@del5.vsnl.net.in";
textcolor(CYAN);
gotoxy(1,7);
cout<<"INSTITUTIONAL PROFILE:";
textcolor(YELLOW);
gotoxy(1,8);
cout<<"IICE is the charitable Institute started in 1992 & IICE has the govenment";
gotoxy(1,9);
cout<<"recognition.It is affiliated to IGNOU for MCA,BCA & other computer related  ";
gotoxy(1,10);
cout<<"programmes,Directorate of Training & Technical Education,Govt. of India and  ";
gotoxy(1,11);
cout<<"is also associated with Cambridge University,U.K";
gotoxy(1,13);
textcolor(CYAN);
cout<<"INFRASTRUCTURAL FACILITIES:";
textcolor(YELLOW);
gotoxy(1,14);
cout<<"Besides lecture rooms the Institute has computer labs,library and hostel facilities ";
gotoxy(1,15);
cout<<"IICE centres are well equiped with all modern facilities required for quality ";
gotoxy(1,16);
cout<<"training programme.";
textcolor(CYAN);
gotoxy(1,18);
cout<<"COURSES:";
textcolor(YELLOW);
gotoxy(1,19);
cout<<"- MCA,BCA,CIC,COPA and latest courses such as Oracle,Visual Basic,VC++,sql ";
gotoxy(1,20);
cout<<"- Advanced Diploma in Fashion Technology,Computer Software,Fashion Design etc.";
gotoxy(1,21);
cout<<"- Certificate courses in Computer Aided Jewellery Designing,Interior Designing ";
textcolor(CYAN);
gotoxy(1,24);
cout<<"< PRESS ANY KEY TO CONTINUE >";
getch();
clrscr();
textcolor(YELLOW);
gotoxy(1,1);
cout<<"FEES:";
gotoxy(1,2);
cout<<"FEES VARIES FROM COURSE TO COURSE";
textcolor(CYAN);
gotoxy(1,23);
cout<<"< PRESS ANY KEY TO RETURN TO COMPUTER EDUCATION MENU >";
getch();
ce();
sound(500);
delay(100);
nosound();
}
else
if(ch=='3')
{
clrscr();
textcolor(CYAN);
gotoxy(1,1);
cout<<"EL-3L ACADEMY";
textcolor(YELLOW);
gotoxy(1,3);
cout<<"509,Vth Floor,Sri Ram Tower,13,Ashok Vihar ,Delhi-110052";
textcolor(CYAN);
gotoxy(1,5);
cout<<"COURSE HIGHLIGHTS:";
textcolor(YELLOW);
gotoxy(1,6);
cout<<"EL-Commerce courses";
gotoxy(1,7);
cout<<"EL-Commerce Web Site Developer-I ";
gotoxy(1,8);
cout<<"Professional E-commerce Web Site Developer -II";
gotoxy(1,9);
cout<<"E-Commerce Web Administrator";
gotoxy(1,10);
cout<<"E-Commerce Web Site Developer-I & II";
gotoxy(1,11);
cout<<"Advanced E-Commerce Web Site Developer-I & II ";
gotoxy(1,13);
cout<<"ELIGIBILITY: ";
gotoxy(1,14);
cout<<"12 years of Formal Education";
gotoxy(1,16);
cout<<"SELECTION:";
gotoxy(1,17);
cout<<"Selection will be on the basis of performance in a written Aptitude test ";
gotoxy(1,19);
cout<<"FEES:";
gotoxy(1,20);
cout<<"VARIES FROM COURSE TO COURSE ";
textcolor(CYAN);
gotoxy(1,24);
cout<<"< PRESS ANY KEY TO RETURN TO COMPUTER EDUCATION MENU >";
getch();
{
clrscr();
ce();
}
sound(500);
delay(100);
nosound();
}
else
if(ch=='4')
{
clrscr();
textcolor(CYAN);
gotoxy(1,1);
cout<<"NIIT";
textcolor(YELLOW);
gotoxy(1,3);
cout<<"NIIT Ltd.,NIIT House,C-125,Okhla Phase 1, New Delhi-110020";
gotoxy(1,4);
cout<<"Tele: 6817341,6810801";
textcolor(CYAN);
gotoxy(1,6);
cout<<"INSTITUTIONAL PROFILE:";
textcolor(YELLOW);
gotoxy(1,7);
cout<<"A Rs 880 crore IT solutions corporation,NIIT began with a mission of bringing";
gotoxy(1,8);
cout<<"people and computers together successfully.NIIT computer training reveals the";
gotoxy(1,9);
cout<<"bottom up approach to acquiring skill sets.   ";
gotoxy(1,11);
textcolor(CYAN);
cout<<"COURSES:";
textcolor(YELLOW);
gotoxy(1,12);
cout<<"-IGNIIT";
gotoxy(1,13);
cout<<"-DNIIT";
gotoxy(1,14);
cout<<"-SWIFT";
gotoxy(1,15);
cout<<"-CATS";
gotoxy(1,16);
cout<<"-MCDBA";
gotoxy(1,17);
cout<<"-MCSD";
gotoxy(1,18);
cout<<"-MCSE ";
gotoxy(1,20);
cout<<"FEES:";
gotoxy(1,21);
cout<<"FEES VARIES FROM COURSE TO COURSE";
textcolor(CYAN);
gotoxy(1,24);
cout<<"< PRESS ANY KEY TO RETURN TO COMPUTER EDUCATION MENU >";
getch();
ce();
sound(500);
delay(100);
nosound();
}
else
if(ch=='5')
{
clrscr();
textcolor(CYAN);
gotoxy(1,1);
cout<<"CMC";
textcolor(YELLOW);
gotoxy(1,3);
cout<<"9th Floor,Shahpuri Towers,C-56 Community centre,Janak Puri,New Delhi-110058";
gotoxy(1,4);
cout<<"Tele: 5534692/3,5534208/9 Fax: 5534249";
textcolor(CYAN);
gotoxy(1,6);
cout<<"INSTITUTIONAL PROFILE:";
textcolor(YELLOW);
gotoxy(1,7);
cout<<"CMC Limited,a Govt. of India enterprise commenced its operations in 1976";
gotoxy(1,8);
cout<<"as Computer Maintenance Coperation and took up the task of servicing all the";
gotoxy(1,9);
cout<<"800 IBM installations when IBM would up its operation in the country in 1978";
gotoxy(1,11);
textcolor(CYAN);
cout<<"COURSES:";
textcolor(YELLOW);
gotoxy(1,12);
cout<<"-PGDCA";
gotoxy(1,13);
cout<<"-PGDIWT";
gotoxy(1,14);
cout<<"-CIT";
gotoxy(1,15);
cout<<"-CDT";
gotoxy(1,16);
cout<<"-CJEC";
gotoxy(1,18);
cout<<"FEES:";
gotoxy(1,19);
cout<<"FEES VARIES FROM COURSE TO COURSE";
textcolor(CYAN);
gotoxy(1,24);
cout<<"< PRESS ANY KEY TO RETURN TO COMPUTER EDUCATION MENU >";
getch();
{
clrscr();
ce();
}
sound(500);
delay(100);
nosound();
}
else
if(ch=='6')
{
clrscr();
textcolor(CYAN);
gotoxy(1,1);
cout<<"LAKHTIA COMPUTER CENTRE(LCC)";
textcolor(YELLOW);
gotoxy(1,3);
cout<<"E-12,Kalkaji,opp Deshbandhu college,New Delhi-110048";
gotoxy(1,4);
cout<<"Tele: 6213456,6418899,6468899 Fax: 622481";
textcolor(CYAN);
gotoxy(1,6);
cout<<"INSTITUTIONAL PROFILE:";
textcolor(YELLOW);
gotoxy(1,7);
cout<<"LCC was estb. since 1985 and has 500 centres spread across the country .";
gotoxy(1,8);
cout<<"LCC was first to launch Modular Training Methodology.";
gotoxy(1,10);
textcolor(CYAN);
cout<<"COURSES:";
textcolor(YELLOW);
gotoxy(1,11);
cout<<"-MICRO COURSES Like: Fundamentals,Windows etc.";
gotoxy(1,12);
cout<<"-MAXI COURSES Like: PC operation,Fox pro etc.";
gotoxy(1,13);
cout<<"-MEGA COURSES Like: Oracle+VB/PB/VC+Dev 2000//VC++";
gotoxy(1,14);
cout<<"-Diploma in Multimedia & Video ELCC";
gotoxy(1,16);
cout<<"FEES:";
gotoxy(1,17);
cout<<"FEES VARIES FROM COURSE TO COURSE";
textcolor(CYAN);
gotoxy(1,24);
cout<<"< PRESS ANY KEY TO RETURN TO COMPUTER EDUCATION MENU >";
getch();
{
clrscr();
ce();
}
sound(500);
delay(100);
nosound();
}
else if (ch==27)
{
menu();
}
}

/****************************************************************************/
//CLASS NAME: career//
//FUNCTION NAME: eo()//
//DETAILS: It displays the information about various options when user press7//
/****************************************************************************/

void career::eo()
{
char ch;
int graphdriver = DETECT,graphmode,errorcode;
initgraph(&graphdriver, &graphmode, "..//bgi");
settextstyle(1,0,3);
setcolor(LIGHTBLUE);
delay(350);
sound(500);
delay(100);
nosound();
outtextxy(99,30,"-MISCELLANEOUS EDUCATION OPTIONS- ");
delay(350);
sound(500);
delay(100);
nosound();
outtextxy(10,55,"1:  Oberoi Centre For Learning");
delay(350);
sound(500);
delay(100);
nosound();
outtextxy(10,85,"2:  National Council For Hotel Management And");
delay(400);
sound(500);
delay(100);
nosound();
outtextxy(10,115,"    Catering Technology");
delay(400);
sound(500);
delay(100);
nosound();
outtextxy(10,145,"3:  International Polytechnic For Women");
delay(400);
sound(500);
delay(100);
nosound();
outtextxy(10,175,"4:  International Centre of Art & Design");
delay(400);
sound(500);
delay(100);
nosound();
outtextxy(10,205,"5:  National Institute of Fashion Technology");
delay(400);
sound(500);
delay(100);
nosound();
outtextxy(10,235,"6:  Wigan & Leigh College");
delay(400);
sound(500);
delay(100);
nosound();
outtextxy(10,265,"7:  Sri Aurobindo Institute of Mass Communication");
delay(400);
sound(500);
delay(100);
nosound();
outtextxy(10,295,"8:  Asian Academy of Film & Television  ");
delay(400);
sound(500);
delay(100);
nosound();
outtextxy(10,325,"9:  Amity Law School of India ");
delay(400);
sound(500);
delay(100);
nosound();
settextstyle(1,0,1);
rectangle(1,460,630,400);
sound(500);
delay(100);
nosound();
outtextxy(10,400,"PRESS <Esc> TO RETURN TO MAIN MENU");
outtextxy(10,417,"PRESS ASSOCIATED No.TO KNOW MORE ABOUT GIVEN INSTIT.");
outtextxy(10,435,"ENTER YOUR CHOICE:");
ch=getch();
closegraph();
if(ch=='1')
{
clrscr();
textcolor(CYAN);
gotoxy(1,1);
cout<<"THE OBEROI CENTRE FOR LEARNING";
textcolor(YELLOW);
gotoxy(1,3);
cout<<"7,SHAM NATH MARG,DELHI-110054";
gotoxy(1,4);
cout<<"Tele: 3890505 Fax: 2929800";
gotoxy(1,5);
cout<<"Telex:3178226 ODML IN";
textcolor(CYAN);
gotoxy(1,7);
cout<<"INSTITUTIONAL PROFILE:";
textcolor(YELLOW);
gotoxy(1,8);
cout<<"The Oberoi School of Hotel Management was established in 1966 by Rai Bahadur";
gotoxy(1,9);
cout<<"M.S.Oberoi and is among the premier Hotel Management Institutes,recognised ";
gotoxy(1,10);
cout<<"by the I.H.A. ,Paris. It has been developing executives for the Oberoi Group. ";
gotoxy(1,11);
cout<<"The trainees are provided with a stipend of Rs. 5500-Rs.7000,housing,meals";
gotoxy(1,12);
cout<<"and medical insurance. ";
gotoxy(1,13);
textcolor(CYAN);
gotoxy(1,15);
cout<<"COURSES:";
textcolor(YELLOW);
gotoxy(1,16);
cout<<"3-year Management Training Programme.";
gotoxy(1,17);
cout<<"3-year Senior Kitchen Training Programme.";
gotoxy(1,18);
cout<<"2-year Housekeeping Training Programme";
gotoxy(1,20);
cout<<"ELIGIBILITY: ";
gotoxy(1,21);
cout<<"Graduates of a recognised university from any discipline and diploma in " ;
gotoxy(1,22);
cout<<"Hotel Management from any institution recognised by National Council for ";
gotoxy(1,23);
cout<<"Hotel Management and Catering Technology";
textcolor(CYAN);
gotoxy(1,24);
cout<<"< PRESS ANY KEY TO RETURN TO MISC.EDUCATION OPTION MENU >";
getch();
eo();
sound(500);
delay(100);
nosound();
}
else
if(ch=='2')
{
clrscr();
textcolor(CYAN);
gotoxy(1,1);
cout<<"NATIONAL C0UNCIL FOR HOTEL MANAGEMANT AND CATERING TECHNOLOGY";
textcolor(YELLOW);
gotoxy(1,3);
cout<<"Library Avenue, Pusa Complex,New-Delhi 110012";
gotoxy(1,4);
cout<<"Tele: 3890505 Fax: 2929800";
gotoxy(1,5);
cout<<"Telex:3178226 ODML IN";
textcolor(CYAN);
gotoxy(1,7);
cout<<"INSTITUTIONAL PROFILE:";
textcolor(YELLOW);
gotoxy(1,8);
cout<<"A government run organisation, which conducts a joint entrance test for ";
gotoxy(1,9);
cout<<"19 hotel management institutions for a 3-year diploma course in hotel  ";
gotoxy(1,10);
cout<<"management. ";
gotoxy(1,11);
cout<<"ELIGIBILITY:";
gotoxy(1,13);
cout<<"Students passing class XII with 50% in any stream are eligible to apply.";
gotoxy(1,14);
textcolor(CYAN);
gotoxy(1,15);
cout<<"Age limit is 22 years.";
textcolor(YELLOW);
gotoxy(1,16);
cout<<"MONTH FOR APPLYING:JANUARY.";
gotoxy(1,17);
cout<<"TEST:APRIL.";
gotoxy(1,19);
cout<<"NOTE:FOR FURTHER INFORMATION,SEE OUR ADVERVISEMENT IN LEADING NEWSPAPERS .";
textcolor(CYAN);
gotoxy(1,24);
cout<<"< PRESS ANY KEY TO RETURN TO MISC.EDUCATION OPTION MENU >";
getch();
eo();
sound(500);
delay(100);
nosound();
}
else
if(ch=='3')
{
clrscr();
textcolor(CYAN);
gotoxy(1,1);
cout<<"INTERNATIONAL POLYTECHNIC FOR WOMEN";
textcolor(YELLOW);
gotoxy(1,3);
cout<<"A-3,SOUTH EXTN. PART-1,NEW DELHI 110049";
gotoxy(1,4);
cout<<"Tele: 4624049 Fax: 6461464";
textcolor(CYAN);
gotoxy(1,7);
cout<<"INSTITUTIONAL PROFILE:";
textcolor(YELLOW);
gotoxy(1,8);
cout<<"";
gotoxy(1,9);
cout<<"Was established in 1979.It provides training in professional specialization ";
gotoxy(1,10);
cout<<"by the I.H.A. ,Paris. It has been developing executives for the Oberoi Group. ";
gotoxy(1,11);
cout<<"The trainees are provided with a stipend of Rs. 5500-Rs.7000,housing,meals";
gotoxy(1,12);
cout<<"and medical insurance. ";
gotoxy(1,13);
textcolor(CYAN);
gotoxy(1,15);
cout<<"COURSES:";
textcolor(YELLOW);
gotoxy(1,16);
cout<<"TEXTILE DESIGN AND TEXTILE PRINTING.";
gotoxy(1,17);
cout<<"MODERN OFFICE MANAGEMENT.";
gotoxy(1,18);
cout<<"HOME SCIENCE";
gotoxy(1,20);
cout<<"ELIGIBILITY: ";
gotoxy(1,21);
cout<<"Graduates of a recognised university from any discipline/10+2 " ;
textcolor(CYAN);
gotoxy(1,24);
cout<<"< PRESS ANY KEY TO RETURN TO MISC.EDUCATION OPTION MENU >";
getch();
eo();
sound(500);
delay(100);
nosound();
}
else
if(ch=='4')
{
clrscr();
textcolor(CYAN);
gotoxy(1,1);
cout<<"International Centre of art and design";
textcolor(YELLOW);
gotoxy(1,3);
cout<<"171-A,khirki road,Malviya Nagar, New-delhi";
gotoxy(1,4);
cout<<"Tele: 6446675 Fax: 6461464";
textcolor(CYAN);
gotoxy(1,7);
cout<<"INSTITUTIONAL PROFILE:";
textcolor(YELLOW);
gotoxy(1,8);
cout<<"main branch at a-3,South Extension-1.";
gotoxy(1,9);
cout<<"I.C.A.D.is among the premier Institutes in fasion designing. ";
gotoxy(1,13);
cout<<"ELIGIBILITY: ";
gotoxy(1,14);
cout<<"Graduates of a recognised university/10+2 with min. 50%.";
textcolor(CYAN);
gotoxy(1,24);
cout<<"< PRESS ANY KEY TO RETURN TO MISC.EDUCATION OPTION MENU >";
getch();
eo();
sound(500);
delay(100);
nosound();
}
else
if(ch=='5')
{
clrscr();
textcolor(CYAN);
gotoxy(1,1);
cout<<"NATIONAL INSTITUTE OF FASHION TECHNOLOGY";
textcolor(YELLOW);
gotoxy(1,3);
cout<<"HAUZ KHAS, NEAR GULMOHAR PARK, NEW DELHI - 110016";
gotoxy(1,4);
cout<<"Tele: 6965080,6965059 Fax: 6851198";
textcolor(CYAN);
gotoxy(1,7);
cout<<"INSTITUTIONAL PROFILE:";
textcolor(YELLOW);
gotoxy(1,8);
cout<<"";
gotoxy(1,9);
cout<<"N.I.F.T.was established in 1986 and has been instrumental in shaping the ";
gotoxy(1,10);
cout<<"fashion industry. It has centres in Delhi,Mumbai and Bangalore." ;
gotoxy(1,12);
cout<<"ELIGIBILITY: ";
gotoxy(1,13);
cout<<"Graduates of a recognised university from any discipline/10+2 with min.50%.";
gotoxy(1,14);
cout<<"FEES : Approx. Rs.17000 per semester.";
textcolor(CYAN);
gotoxy(1,24);
cout<<"< PRESS ANY KEY TO RETURN TO MISC.EDUCATION OPTION MENU >";
getch();
eo();
sound(500);
delay(100);
nosound();
}

else
if(ch=='6')
{
clrscr();
textcolor(CYAN);
gotoxy(1,1);
cout<<"WIGAN AND LEIGH COLLEGE";
textcolor(YELLOW);
gotoxy(1,3);
cout<<"401-402,SKIPPER CORNER, 88,NEHRU-PLACE,NEW-DELHI-19.";
gotoxy(1,4);
cout<<"Tele: 6443333 Fax: 6451028";
gotoxy(1,9);
cout<<"ELIGIBILITY:";
gotoxy(1,11);
cout<<"Students passing class XII with 50% in any stream are eligible to apply.";
gotoxy(1,14);
textcolor(CYAN);
gotoxy(1,13);
cout<<"Age limit is 22 years.";
textcolor(YELLOW);
gotoxy(1,16);
cout<<"MONTH FOR APPLYING:JANUARY.";
gotoxy(1,17);
cout<<"TEST:APRIL.";
gotoxy(1,19);
cout<<"NOTE:FOR FURTHER INFORMATION,SEE OUR ADVERVISEMENT IN LEADING NEWSPAPERS .";
textcolor(CYAN);
gotoxy(1,24);
cout<<"< PRESS ANY KEY TO RETURN TO MISC.EDUCATION OPTION MENU >";
getch();
eo();
sound(500);
delay(100);
nosound();
}
else
if(ch=='7')
{
clrscr();
textcolor(CYAN);
gotoxy(1,1);
cout<<"SRI AUROBINDO INSTITUTE OF MASS COMMUNICATION";
textcolor(YELLOW);
gotoxy(1,3);
cout<<"AUROBINDO ASHRAM,NEAR IIT,HAUZ KHAS,NEW-DELHI.";
gotoxy(1,4);
cout<<"Tele: 6524798 Fax: 6857449";
gotoxy(1,9);
cout<<"ELIGIBILITY:";
gotoxy(1,11);
cout<<"Students passing class XII with 50% in any stream are eligible to apply.";
gotoxy(1,14);
textcolor(CYAN);
gotoxy(1,13);
cout<<"Age limit is 22 years.";
textcolor(YELLOW);
gotoxy(1,16);
cout<<"MONTH FOR APPLYING:JANUARY.";
gotoxy(1,17);
cout<<"TEST:APRIL.";
gotoxy(1,19);
cout<<"NOTE:FOR FURTHER INFORMATION,SEE OUR ADVERVISEMENT IN LEADING NEWSPAPERS .";
textcolor(CYAN);
gotoxy(1,24);
cout<<"< PRESS ANY KEY TO RETURN TO MISC.EDUCATION OPTION MENU >";
getch();
eo();
sound(500);
delay(100);
nosound();
}
else
if(ch=='8')
{
clrscr();
textcolor(CYAN);
gotoxy(1,1);
cout<<"ASIAN ACADEMY OF FILM AND TELEVISION.";
textcolor(YELLOW);
gotoxy(1,3);
cout<<"MARWAH STUDIOS COMPLEX,FC-14/15,FILM CITY,SECTOR-16A,NOIDA 201301,UP.";
gotoxy(1,4);
cout<<"Tele: 4515254 Fax: 4515246";
gotoxy(1,9);
cout<<"ELIGIBILITY:";
gotoxy(1,11);
cout<<"Students passing class XII with 50% in any stream are eligible to apply.";
gotoxy(1,14);
textcolor(CYAN);
gotoxy(1,13);
cout<<"Age limit is 22 years.";
textcolor(YELLOW);
gotoxy(1,16);
cout<<"MONTH FOR APPLYING:JANUARY.";
gotoxy(1,17);
cout<<"NOTE:FOR FURTHER INFORMATION,SEE OUR ADVERVISEMENT IN LEADING NEWSPAPERS .";
textcolor(CYAN);
gotoxy(1,24);
cout<<"< PRESS ANY KEY TO RETURN TO MISC.EDUCATION OPTION MENU >";
getch();
eo();
sound(500);
delay(100);
nosound();
}
else
if(ch=='9')
{
clrscr();
textcolor(CYAN);
gotoxy(1,1);
cout<<"AMITY LAW SCHOOL OF INDIA.";
textcolor(YELLOW);
gotoxy(1,3);
cout<<"E-27,DEFENCE COLONY,NEW-DELHI-24.";
gotoxy(1,4);
cout<<"Tele: 4621960-62 Fax: 4623317";
gotoxy(1,9);
cout<<"ELIGIBILITY:";
gotoxy(1,11);
cout<<"Students passing class XII with 50% in any stream are eligible to apply.";
gotoxy(1,14);
textcolor(CYAN);
gotoxy(1,13);
cout<<"Age limit is 22 years.";
textcolor(YELLOW);
gotoxy(1,16);
cout<<"MONTH FOR APPLYING:APRIL.";
gotoxy(1,17);
cout<<"NOTE:FOR FURTHER INFORMATION,SEE OUR ADVERVISEMENT IN LEADING NEWSPAPERS .";
textcolor(CYAN);
gotoxy(1,24);
cout<<"< PRESS ANY KEY TO RETURN TO MISC.EDUCATION OPTION MENU >";
getch();
eo();
sound(500);
delay(100);
nosound();
}
else
if(ch==27)
{
menu();
sound(500);
delay(100);
nosound();
}
}

/****************************************************************************/
//CLASS NAME: career//
//FUNCTION NAME: end()//
//DETAILS: It ends the project when user press 0 in main menu //
/****************************************************************************/

void career::end()
{
cleardevice();
setcolor(LIGHTRED);
settextstyle(1,0,4);
outtextxy(5,200,"THIS IS AN EFFORT FROM US FOR YOUR");
outtextxy(10,240,"BETTER FUTURE ");
delay(2500);
for(int p=200;p<=400;p++)
{
setbkcolor(p/29);
sound(100*p*32-100);
cleardevice();
outtextxy(200,300,"YOU ARE EXITING");
outtextxy(200,380,"WAIT....");
delay(10);
}
}


/****************************************************************************/
//FUNCTION NAME: main()//
//DETAILS: It controls over all the functions declared in the program //
/****************************************************************************/

void main()
{
char reply;
textcolor(YELLOW);
career m;
clrscr();
m.start();
int counter;
for(counter=16;counter<=166;counter++)
{
sound(100+(10*counter));
delay(10);
}nosound();
cout<<'\n'<<'\n'<<'\n'<<'\t'<<'\t';
textcolor(CYAN+BLINK);
cprintf("Please send your views at sendme@hotmail.com");
textcolor(BROWN);
cout<<"\n\n\n\n\n\n\t\t\t";
cprintf("Carrer Councelling 2K");
cout<<"\n\t\t\t";
cprintf("_____________________");
cout<<"\n\n\n\t\t\t";
cprintf("Copyright (C) GDG Software Corp.");
cout<<"\n\t\t\t";
cprintf("2000 - 2001");
textcolor(MAGENTA);
cout<<"\n\n\t\t\t";
cprintf("Unregistered Version");
cout<<"\n\n\t\t\t";
cprintf("This is an unregistered version.");
cout<<"\n\t\t\t";
cprintf("Do you want to register it now ? (Y/N)");
cin>>reply;
if (toupper(reply) == 'N')
{
exit(0);
}
m.Password();
clrscr();
textcolor(LIGHTGREEN);
m.informations();
m.Performa();
m.inst();
m.Aim();
m.menu();
getch();
clrscr();
}


/******************************************************************************/
/************************** END OF PROGRAM CODE********************************/
/******************************************************************************/