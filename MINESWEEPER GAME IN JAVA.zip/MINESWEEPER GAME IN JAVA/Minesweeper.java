import java.util.Random;
import javax.swing.JPanel;
import javax.swing.*;
import java.awt.GridLayout;
public class Minesweeper{
  /*
  0: empty space:
  1 ~ 8 : bomb next to it
  9: key bomb (same bomb for successfully uncovered bombs in fail and pass)
  10: flag
  11: unused
  12: incorrect flags
  13: the bomb user clicked in loss
  14: covered space
  */
  private int length, width; //sets the length and width
  private Cell[][] array;
  protected int[][] key;
  protected int[][] userArray;
  private int[][] chainReactionSet;
  private int bombs;
  private Random box;
  protected JPanel board;
  //add mouse event here?
  public Minesweeper(){

    box = new Random();
  }

  public void easy(){
    length = 10;
    width = 10;
    bombs = 10;
  }

  public void medium(){
    length = 16;
    width = 16;
    bombs = 40;
  }

  public void hard(){
    length = 30;
    width = 35;
    bombs = 99;
  }
  public void buildInit(){
    bombInit();
    buildBoard();
    chainReactionSet = new int[key.length][];
    for(int i = 0; i < key.length; i++){
      chainReactionSet[i] = key[i].clone();
    }
  }
  public void bombInit(){
    key = new int[length][width];
    for(int i = 0; i< bombs; i++){
      key[box.nextInt(length)][box.nextInt(width)] = 9;
    }
    toString(key);
    numberSet();
    genUserArray();
  }
  //needs fixing
  public void winValidate(){
    //conditions: ALL flags must be CORRECTLY paired with ALL the bombs AND all blank spaces must be cleared out
    boolean isWin = true;
    for(int i = 0 ; i < userArray.length; i ++){
      for(int a = 0 ; a < userArray[0].length; a++){
        if(array[i][a].isMine == true && array[i][a].isFlagged == false){ //checks to see all bombs are paired with correct flags
          isWin = false;

        }

        else if(array[i][a].isFlagged == false && array[i][a].isEnabled == true){
          isWin = false;

        }
      }
    }
    if(isWin == true){
      win();
    }

  }
  public void win(){
    for(int i = 0; i < key.length; i++){
      for(int a = 0; a < key[0].length; a++){
        array[i][a].isEnabled = false;
      }
    }
    JOptionPane.showMessageDialog(null, "You won");
  }



  private void numberSet(){

    for (int i = 0; i < key.length; i++){
      for (int a = 0; a < key[0].length; a++){
        //If it Is not a mine
        if (key[i][a] == 0){
          int count = 0;
          //Position of cells around key[i][a] relative to key[i][a]
          for (int x = -1; x < 2; x++){
            for (int y = -1; y < 2; y++){
              //Storing x and y test points
              int testX = i + x;//testX = i-1, i, and i+1
              int testY = a + y;//testY = i-1, y, and y+1
              //If the testX and testY values are within the range of the array
              if ((testX >= 0 && testX < length) && (testY >= 0 && testY < width)){
                //If there is a mine
                if (key[testX][testY] == 9){count++;}

              }
            }
          }
          key[i][a] = count;


        }

      }
    }
  }

  private void genUserArray(){
    userArray = new int[length][width];
    for(int i = 0; i < userArray.length; i++){
      for(int a = 0; a < userArray[0].length; a++){
        userArray[i][a] = 14;
      }
    }
  }

  private JPanel buildBoard(){

    board = new JPanel(new GridLayout(length,width));
    array = new Cell[length][width];
    for(int i = 0; i < userArray.length; i++){ //set all the arrays in the cell array to 14
      for(int a =0 ; a < userArray[0].length; a++){
        array[i][a] = new Cell(i,a,this);
        array[i][a].changeIcon(userArray[i][a]);
        if(key[i][a] == 9){array[i][a].isMine = true;}
        //System.out.println("here");
        board.add(array[i][a].button);
      }
    }
    return board;
  }

  public void chainReaction(int col, int row){
    chainReactionSet[col][row] = -2;
    if(key[col][row] != 0){
      array[col][row].updateNum(key[col][row]);
      array[col][row].isEnabled = false;
      array[col][row].isNumbered = true;
    }
    else if(key[col][row] == 0){
      array[col][row].changeIcon(key[col][row]);
      array[col][row].isEnabled = false;
      array[col][row].isBlank = true;
      for (int x = -1; x < 2; x++){
        for (int y = -1; y < 2; y++){
          //Storing x and y test points
          int testX = col + x;//testX = i-1, i, and i+1
          int testY = row + y;//testY = i-1, y, and y+1
          //If the testX and testY values are within the range of the array
          if ((testX >= 0 && testX < length) && (testY >= 0 && testY < width)){
            //If there is a mine
            if (key[testX][testY] != 9 && chainReactionSet[testX][testY] != -2){


              chainReaction(testX,testY);

            }

          }
        }

      }
    }


  }
  public static void toString(int[][] arr){
    for(int a[] : arr){
      for(int b : a){
        System.out.print(b + " ");
      }
      System.out.println();
    }
  }
  public void fail(){
    for(int i = 0; i < userArray.length; i++){
      for(int a = 0; a < userArray[0].length; a++){
        array[i][a].isEnabled = false;
        if(userArray[i][a] == 13){
          continue;
        }
        if(userArray[i][a] == 10 && key[i][a] != 9){
          array[i][a].changeIcon(12);
        }
        else if(userArray[i][a] == 10 && key[i][a] == 9){
          continue;
        }
        else if(key[i][a] == 0 || key[i][a] == 9){
          array[i][a].changeIcon(key[i][a]);
        }
        else{
          array[i][a].updateNum(key[i][a]);
        }
      }
    }
    JOptionPane.showMessageDialog(null, "You lost");
  }
}
