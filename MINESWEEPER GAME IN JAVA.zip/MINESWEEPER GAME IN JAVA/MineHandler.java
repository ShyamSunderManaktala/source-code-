import java.util.Scanner;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.BoxLayout;
import javax.swing.*;
import java.awt.Image;
import java.awt.Component;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseAdapter;

public class MineHandler extends JFrame{
  protected Minesweeper obj; //has the "board"
  private JPanel god; //minesweeper layout design
  private JPanel menu; //menu layout design (preceding god)
  private JPanel top, bottom; //top and bottom stuff on the board

  private ImageIcon cover;

  private JButton easy, medium, hard, custom; //button layout
  private JButton menuReturn;
  private JLabel text, image, difficulty;
  public static void main(String[] args){
    MineHandler crystal = new MineHandler();
  }
  public MineHandler(){

    obj = new Minesweeper();
    menuOpener();
  }

  //you'll need to clean up the UI in a bit
  public void menuOpener(){ //brings up the main menu
    setTitle("Minesweeper");
    setSize(300,400);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    setResizable(false);

    menu = new JPanel();
    menu.setLayout(new BoxLayout(menu, BoxLayout.Y_AXIS));


    text = new JLabel();
    text.setText("Minesweeper");
    text.setAlignmentX(Component.CENTER_ALIGNMENT);

    cover = new ImageIcon("../img/icon.png");
    image = new JLabel(cover);
    image.setAlignmentX(Component.CENTER_ALIGNMENT);

    easy = new JButton();
    easy.setText("Easy");
    easy.addMouseListener(new MouseAdapter(){
      public void mouseClicked(MouseEvent e){
        obj.easy();
        obj.buildInit();
        difficulty = new JLabel();
        difficulty.setText("EASY Mode: Minesweeper");
        buildGui();
      }
    });
    easy.setAlignmentX(Component.CENTER_ALIGNMENT);

    medium = new JButton();
    medium.setText("Medium");
    medium.addMouseListener(new MouseAdapter(){
      public void mouseClicked(MouseEvent e){
        obj.medium();
        obj.buildInit();
        setSize(400,400);
        difficulty = new JLabel();
        difficulty.setText("MEDIUM Mode: Minesweeper");
        buildGui();
      }
    });
    medium.setAlignmentX(Component.CENTER_ALIGNMENT);

    hard = new JButton();
    hard.setText("Hard");
    hard.addMouseListener(new MouseAdapter(){
      public void mouseClicked(MouseEvent e){
        obj.hard();
        obj.buildInit();
        setSize(1000,1000);
        difficulty = new JLabel();
        difficulty.setText("HARD Mode: Minesweeper");
        buildGui();
      }
    });
    hard.setAlignmentX(Component.CENTER_ALIGNMENT);

    custom = new JButton();
    custom.setText("Custom");
    custom.addMouseListener(new MouseAdapter(){
      public void mouseClicked(MouseEvent e){
        System.out.println("custom");
      }
    });
    custom.setAlignmentX(Component.CENTER_ALIGNMENT);

    menu.add(text);
    menu.add(image);
    menu.add(easy);
    menu.add(medium);
    menu.add(hard);
    menu.add(custom);

    add(menu);

    setVisible(true);
  }
  public void buildGui(){
    getContentPane().removeAll();
    getContentPane().repaint();

    System.out.println("Build Gui intiated");


    god = new JPanel(new BorderLayout());
    //board = obj.buildBoard();

    top = new JPanel();

    top.add(difficulty);

    bottom = new JPanel();
    menuReturn = new JButton();
    menuReturn.setText("Return to Menu");
    menuReturn.addMouseListener(new MouseAdapter(){
      public void mouseClicked(MouseEvent e){
        getContentPane().removeAll();
        getContentPane().repaint();

        menuOpener();
        validate();
      }
    }); //add mouse listener



    bottom.add(menuReturn);


    god.add(obj.board, BorderLayout.CENTER);
    god.add(top, BorderLayout.NORTH);
    god.add(bottom, BorderLayout.SOUTH);
    add(god);
    validate();
  }

}

//begin to implement flag operations Minesweeper.java