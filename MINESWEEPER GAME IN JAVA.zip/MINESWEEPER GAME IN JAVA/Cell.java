import javax.swing.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseAdapter;
import java.awt.Insets;
public class Cell{
  private ImageIcon image;
  protected int status, col,row; //status records the current STATUS OF THE CELL
  protected JButton button;
  private Minesweeper miney;
  protected boolean isEnabled;
  protected boolean isMine;
  protected boolean isFlagged;
  protected boolean isNumbered;
  protected boolean isBlank;
  //protected Mouse mouseBox;
  public Cell(int i,int a, Minesweeper miney){
    isEnabled = true;
    isFlagged = false;
    isBlank = false;
    col = i;
    row = a;
    this.miney = miney;
    //mouseBox = new Mouse(i,a);
    button = new JButton();
    //button.addMouseListener(mouseBox);
    button.addMouseListener(new MouseAdapter(){
      public void mouseClicked(MouseEvent e){

        if(e.getButton() == MouseEvent.BUTTON1){
          if(isEnabled){
            if(miney.userArray[col][row] == 10){}
            else if(miney.key[col][row] == 9){
              miney.userArray[col][row] = 13;
              changeIcon(13);
              miney.fail();
            }
            else if(miney.key[col][row] == 0){
              miney.chainReaction(col,row);

            }

            else{
              if(isEnabled){
                miney.userArray[col][row] = miney.key[col][row];
                updateNum(miney.key[i][a]);
                isEnabled = false;
                isNumbered = true;
              }

            }
            miney.winValidate();
          }

        }
        else if(e.getButton() == MouseEvent.BUTTON3){
          if(isEnabled){
            if(miney.userArray[col][row] == 10){
              miney.userArray[col][row] = 14;
              status = 14;
              changeIcon(14);
              isFlagged = false;
            }
            else if(miney.userArray[col][row] == 14){
              miney.userArray[col][row] = 10;
              status = 10;
              changeIcon(10);
              isFlagged = true;
            }
            miney.winValidate();
          }

        }

      }
    });

  }
  public void updateNum(int num){
    status = num;
    button.setIcon(null);
    String text = Integer.toString(num);
    System.out.println(num);
    button.setText(text);

    button.setBorder(null);
    button.setBorderPainted(false);
    button.setMargin(new Insets(0,0,0,0));
    button.setEnabled(false);
  }
  public void changeIcon(int img){ //adds the image to the button
    status = img;
    String directory = "../img/" + status + "box.png";
    ImageIcon box = new ImageIcon(directory);


    button.setIcon(box);

  }
  public JButton addCell(){//adds the cell to the larger array
    return button;
  }
}
