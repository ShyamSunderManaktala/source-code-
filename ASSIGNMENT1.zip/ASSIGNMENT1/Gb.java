interface Gb
{
	public void hide();
}