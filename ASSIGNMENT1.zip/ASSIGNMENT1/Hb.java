abstract class Hb
{
	 // public  abstract Hb();
 abstract public void   doHn();
 abstract public Kb  getHn();
 abstract public String  concreteHn();
}