class UIDDEMO 
{
	public UIDDEMO()
	{
	}

	public long getUID()
	{
long n = 161977047;


		return n;
}
}