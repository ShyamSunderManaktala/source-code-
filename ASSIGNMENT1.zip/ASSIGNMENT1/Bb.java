
import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;


class Bb extends JFrame implements Gb, ActionListener 
{
	private Eb gv;
public JButton loadButton;
public JTextField fileName;
public  JTextField firstLine;
public JButton saveButton;
public Bb(Eb  p)

	{

setVisible(true);
            setSize(800,800);
            JPanel rPanel = new JPanel(new GridLayout(2,2));
            add(rPanel);

           
             fileName = new JTextField(" ENTER A FILE NAME TO STORE TEXT"); rPanel.add(fileName);
           
             firstLine = new JTextField("ENTER THE TEXT LINE TO WRITE IN FILE SPECIFIED"); rPanel.add(firstLine);
            
            loadButton  = new JButton(); rPanel.add(loadButton);
			loadButton.setText("load firstline");
			loadButton.addActionListener(this);
			
            saveButton = new JButton(); rPanel.add(saveButton);
			saveButton.setText("save to file");
			saveButton.addActionListener( this);

			addWindowListener(new WindowAdapter()
      {
         public void windowClosing(WindowEvent e)
         {
           dispose();
           System.exit(0); //calling the method is a must
         }
      });


	}
public Eb getEb()

	{
		Cb s= new Cb();

Eb t= new Eb(s);

return t;

	}

public static  void hmm()

	{


 
	}


public void  hide()
	{

	}


public void actionPerformed(ActionEvent e )
	{
if(e.getSource() == loadButton)
		{
String s= fileName.getText();
showFirstLineOfFile(s);
		}
else if (e.getSource() == saveButton)

{
	String s1 = fileName.getText();
	String s2 = firstLine.getText();
	saveLineToFile(s1,s2);
	

} 


            




	}
public void showFirstLineOfFile(String fileName)
	{

try
{
	File file = new File( fileName); 
  
  BufferedReader br = new BufferedReader(new FileReader(file)); 
  
  String st; 
  st = br.readLine(); 
    firstLine.setText(st);
	br.close();
}
catch ( Exception e)
{

	e.printStackTrace();
}


	}


public void saveLineToFile(String fileName,String line)
	{
try
{
	File file = new File( fileName); 
  
  BufferedWriter  br = new BufferedWriter(new FileWriter(file)); 
  
  String st; 
   br.write(line); 
  br.close();
    

	
}
catch ( Exception e)
{
	e.printStackTrace();
}
	
	}



}