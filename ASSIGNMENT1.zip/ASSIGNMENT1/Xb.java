interface Xb
{
public void doXn(int a);
public String getXn();
}