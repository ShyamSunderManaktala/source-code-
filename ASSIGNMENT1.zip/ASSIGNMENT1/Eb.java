class Eb extends lb 
	
	{
	private Cb gv;
public Eb(Cb m)
	{
	gv=m;
	}

public int fact (int p )
	{
	int q  = p;

	return q;

	}


public Cb getIn()
	{
Cb r= new Cb();

return r;

	}


public void doIn()

	{}

}