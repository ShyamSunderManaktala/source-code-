class Zb implements Ab
{
	private Cb bv;
public Zb()
	{

	}


public Zb getZn()
	{
Zb  t = new Zb();

return t;


	}


public void doZn()
	{
	System.out.println("World");
	}


public void  doNowt ()
	{
	}

}