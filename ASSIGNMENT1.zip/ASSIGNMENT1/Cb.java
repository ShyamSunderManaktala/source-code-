class Cb implements b
{
	private Kb  cv;
 public Cb()
	{
	}

public int fact (int m )
	{
int p = m;

return p;
	}
public void doCn()

	{
	}

}