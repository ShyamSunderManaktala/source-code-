abstract class lb implements b
{
	//public lb();
 abstract public Cb getIn();
abstract public void doIn();
}