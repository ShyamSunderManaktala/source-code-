interface Fb
{
	public String getName();
}