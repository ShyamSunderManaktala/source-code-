class Kb implements Xb
{
	
	public Kb()
	{
		
	}

public void  doXn(int  b )

	{

while(b != 0)
		{
if (b % 2 == 0){

	String s = getXn();

System.out.println(s+" "+b);

b--;
	}
	else
		
			{
				b--;
		continue;
			}
	}
	}
public String getXn()

	{

String s ="message" ;
		return s;
	}


public void doKn()
	{
int n =100;
doXn(100);



	}


}
