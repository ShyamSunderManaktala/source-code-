interface b
{
	public int fact(int b);
}