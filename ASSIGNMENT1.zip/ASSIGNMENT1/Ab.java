interface Ab
{
	public void doNowt ();
}