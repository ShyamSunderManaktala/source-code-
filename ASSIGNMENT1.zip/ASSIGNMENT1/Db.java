import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class Db extends Mb
{
	private Zb hv;
private String msg;

public Db(Zb a,String b)
	{
	
	
	
	}

public static void main(String  args[])
	{
 new Bb(new Eb(new Cb()));
 Db  t= new Db(new Zb(), "hello");

   t.doXn(100);
	}

public void doXn(int a )
	{
new Kb().doXn(a);

	}
public String getXn()

	{
String t = "dine";
	return t;

	}

public Zb getMn()
	{
Zb m= new Zb();


return m;
	}



public void doMn()
	{
	}

}






