class Yb extends Hb
{
 private Kb f ;   
 
public Yb(Kb r)
	{


	}


public void doHn()

	{

	}
public Kb getHn()
	{
Kb t= new Kb();

return t;

	}
public  String concreteHn()
	{

		String b="fine";

		return b;
	}


public void saveText (String fileName,String txt )
	{

	}


public String readFirstLineOfFile(String fileName)

	{

		String b= fileName;

		return b;
}
}
