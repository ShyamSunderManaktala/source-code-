abstract class Mb implements Xb
{
	//public Mb();
abstract public Zb   getMn();
abstract public void  doMn();
}