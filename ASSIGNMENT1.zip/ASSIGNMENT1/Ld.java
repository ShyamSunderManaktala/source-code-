class Ld implements Fb
{
	private Eb gv ;
public Ld(Eb c)
	{
	}
public String getName(){

	String b ="demo";
	return b;
}

	

public Eb getEb()

	{
Eb d= new Eb(new Cb());
return d;
	}

public static String getSillyName()
	{
	String t= "fine" ;

	return t;
	}

	

}
